namespace XIVHubCompanion.Apps
{
    public interface IApp
    {
        string Name { get; }
        string Icon { get; }
        void Draw();
        void Dispose();
    }
}
