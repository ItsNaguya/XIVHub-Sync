using Dalamud.Bindings.ImGui;
using System.Numerics;

namespace XIVHubCompanion.Apps
{
    public class CraftingApp : IApp
    {
        public string Name => "Crafting";
        public string Icon => ((char)Dalamud.Interface.FontAwesomeIcon.Hammer).ToString();
        private DataSender _sender;

        public CraftingApp(DataSender sender)
        {
            _sender = sender;
        }

        public void Draw()
        {
            ImGui.TextWrapped("Crafting Module Active");
            ImGui.Spacing();
            ImGui.TextColored(new Vector4(0.8f, 0.8f, 0.8f, 1.0f), "This module automatically scans your inventory, saddlebags, and retainers to cross-reference materials required for your active XIV Hub crafting pipelines.");
            
            ImGui.Spacing(); ImGui.Separator(); ImGui.Spacing();

            ImGui.TextColored(new Vector4(0.13f, 0.77f, 0.36f, 1.0f), "Status: Awaiting Pipeline Data");
            ImGui.TextWrapped("Create a Crafting Pipeline on the website. The Companion will highlight missing materials you still need to gather or buy.");
            
            ImGui.Spacing(); ImGui.Spacing();
            
            Vector4 btnBg = new Vector4(0.12f, 0.12f, 0.14f, 1.0f);
            Vector4 btnHover = new Vector4(0.0f, 0.65f, 1.0f, 1.0f);
            Vector4 btnText = new Vector4(0.9f, 0.9f, 0.9f, 1.0f);
            Vector4 btnHoverText = new Vector4(1.0f, 1.0f, 1.0f, 1.0f);
            
            if (UIHelper.DrawGarlondButton("btn_force_sync", ImGui.GetCursorScreenPos(), new Vector2(200, 35) * PluginUI.AppScale, "Force Inventory Sync", btnBg, btnHover, btnText, btnHoverText))
            {
                // UI button placeholder
                ImGui.OpenPopup("SyncTriggered");
            }
            ImGui.Dummy(new Vector2(0, 35) * PluginUI.AppScale);

            if (ImGui.BeginPopup("SyncTriggered"))
            {
                ImGui.Text("Inventory snapshot triggered.");
                if (UIHelper.DrawGarlondButton("btn_close_sync", ImGui.GetCursorScreenPos(), new Vector2(80, 25) * PluginUI.AppScale, "Close", btnBg, btnHover, btnText, btnHoverText)) ImGui.CloseCurrentPopup();
                ImGui.Dummy(new Vector2(0, 25) * PluginUI.AppScale);
                ImGui.EndPopup();
            }
        }

        public void Dispose()
        {
        }
    }
}
