using Dalamud.Bindings.ImGui;
using System.Numerics;

namespace XIVHubCompanion.Apps
{
    public class RoutinesApp : IApp
    {
        public string Name => "Routines";
        public string Icon => ((char)Dalamud.Interface.FontAwesomeIcon.ClipboardCheck).ToString();

        public void Draw()
        {
            ImGui.TextWrapped("Routines Module");
            ImGui.Spacing();
            ImGui.TextColored(new Vector4(0.8f, 0.8f, 0.8f, 1.0f), "Automate your daily and weekly checklists seamlessly.");
            
            ImGui.Spacing(); ImGui.Separator(); ImGui.Spacing();

            ImGui.TextColored(new Vector4(0.13f, 0.77f, 0.36f, 1.0f), "Status: Standby");
            ImGui.TextWrapped("Your configured routines on XIV Hub will automatically sync here, providing on-screen overlays for your daily tasks.");
        }

        public void Dispose()
        {
        }
    }
}
