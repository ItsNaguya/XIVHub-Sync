using System;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Dalamud.Plugin.Services;

namespace XIVHubCompanion
{
    public class DataSender
    {
        private readonly HttpClient _client;
        private readonly HttpClient _sseClient;
        private readonly string _endpointUrl = "https://xiv.naguya.tech/api/local/sync";
        private readonly string _streamUrl = "https://xiv.naguya.tech/api/local/stream";
        private readonly IPluginLog _log;
        
        private CancellationTokenSource _streamCts;

        public event Action<string, string> OnServerEventReceived;
        public event Action<string> OnError;
        public event Action<string> OnSuccess;

        public string CurrentUserRole { get; private set; } = "user";

        public int TotalSyncs { get; private set; } = 0;
        public int FailedSyncs { get; private set; } = 0;
        public DateTime LastSyncTime { get; private set; } = DateTime.MinValue;
        public string LastSyncStatus { get; private set; } = "Never synced";

        public DataSender(IPluginLog log, Configuration config)
        {
            _log = log;
            _client = new HttpClient();
            _client.Timeout = TimeSpan.FromSeconds(120);
            _client.DefaultRequestHeaders.Add("User-Agent", "XIVHubCompanion/1.0");
            _sseClient = new HttpClient();
            _sseClient.Timeout = Timeout.InfiniteTimeSpan;
            _sseClient.DefaultRequestHeaders.Add("User-Agent", "XIVHubCompanion/1.0");
            
            AttachAuthHeader(config);
        }

        public async Task VerifyUserAsync(string name, string world, Configuration config)
        {
            try
            {
                var response = await _client.GetAsync($"https://xiv.naguya.tech/api/local/verify?name={Uri.EscapeDataString(name)}&world={Uri.EscapeDataString(world)}");
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<dynamic>(content);
                    
                    string role = (string)(data?.role ?? "user");
                    CurrentUserRole = role;

                    if (data.verified == true && data.xivhubId != null)
                    {
                        config.XivHubId = data.xivhubId;
                        config.IsVerified = true;
                        config.Save();
                        AttachAuthHeader(config);
                        _log.Info($"Successfully verified with XIVHub. Token: {config.XivHubId}, Role: {role}");
                    }
                }
            }
            catch (Exception ex)
            {
                _log.Error($"Failed to verify user: {ex.Message}");
            }
        }

        private void AttachAuthHeader(Configuration config)
        {
            if (!string.IsNullOrEmpty(config?.XivHubId))
            {
                _client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", config.XivHubId);
                _sseClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", config.XivHubId);
            }
        }

        public void StartStreaming()
        {
            if (_streamCts != null) return;
            _streamCts = new CancellationTokenSource();
            Task.Run(() => ConnectToStream(_streamCts.Token));
        }

        public void StopStreaming()
        {
            _streamCts?.Cancel();
            _streamCts = null;
        }

        private async Task ConnectToStream(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    _log.Debug($"Connecting to SSE stream at {_streamUrl}...");
                    using var request = new HttpRequestMessage(HttpMethod.Get, _streamUrl);
                    request.Headers.Add("Accept", "text/event-stream");
                    request.Headers.Add("User-Agent", "XIVHubCompanion/1.0");
                    request.Headers.Add("User-Agent", "XIVHubCompanion/1.0");

                    using var response = await _sseClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, token);
                    response.EnsureSuccessStatusCode();
                    
                    _log.Debug("SSE stream connected successfully.");

                    using var stream = await response.Content.ReadAsStreamAsync(token);
                    using var reader = new StreamReader(stream);

                    string eventType = "message";
                    
                    while (!token.IsCancellationRequested && !reader.EndOfStream)
                    {
                        var line = await reader.ReadLineAsync(token);
                        if (string.IsNullOrWhiteSpace(line)) continue;

                        if (line.StartsWith("event:"))
                        {
                            eventType = line.Substring(6).Trim();
                        }
                        else if (line.StartsWith("data:"))
                        {
                            var data = line.Substring(5).Trim();
                            if (eventType != "ping")
                            {
                                OnServerEventReceived?.Invoke(eventType, data);
                            }
                        }
                    }
                }
                catch (TaskCanceledException) { break; }
                catch (Exception ex)
                {
                    _log.Debug($"SSE Stream error: {ex.Message}. Reconnecting in 5s...");
                    await Task.Delay(5000, token);
                }
            }
        }

        public void SendDataAsync(object data)
        {
            Task.Run(async () =>
            {
                try
                {
                    var json = JsonConvert.SerializeObject(data);
                    var content = new StringContent(json, Encoding.UTF8, "application/json");
                    
                    var response = await _client.PostAsync(_endpointUrl, content);
                    LastSyncTime = DateTime.Now;
                    TotalSyncs++;

                    if (!response.IsSuccessStatusCode)
                    {
                        FailedSyncs++;
                        LastSyncStatus = $"Error: {response.StatusCode}";
                        // Don't spam warnings if it fails repeatedly
                        _log.Debug($"Failed to sync to XIV Hub: {response.StatusCode}");
                    }
                    else
                    {
                        LastSyncStatus = "Success";
                        _log.Debug($"Synced data successfully.");
                    }
                }
                catch (Exception ex)
                {
                    LastSyncTime = DateTime.Now;
                    TotalSyncs++;
                    FailedSyncs++;
                    LastSyncStatus = $"Exception: {ex.Message}";
                    _log.Debug($"Could not connect to XIV Hub: {ex.Message}");
                }
            });
        }

        public void SendActionAsync(object data)
        {
            Task.Run(async () =>
            {
                try
                {
                    var json = JsonConvert.SerializeObject(data);
                    var content = new StringContent(json, Encoding.UTF8, "application/json");
                    await _client.PostAsync("https://xiv.naguya.tech/api/local/action", content);
                }
                catch (Exception ex)
                {
                    _log.Debug($"Failed to send action: {ex.Message}");
                }
            });
        }

        public async Task<string> CalculateRouteAsync(object payload)
        {
            try
            {
                var json = JsonConvert.SerializeObject(payload);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                
                var response = await _client.PostAsync("https://xiv.naguya.tech/api/market/calculate", content);
                response.EnsureSuccessStatusCode();
                return await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Failed to calculate route remotely.");
                return null;
            }
        }

        public async Task<string> PullMarketStateAsync(string characterName)
        {
            try
            {
                var response = await _client.GetAsync($"https://xiv.naguya.tech/api/local/market/sync?name={Uri.EscapeDataString(characterName)}");
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Failed to pull market state.");
            }
            return null;
        }

        public async Task PushMarketStateAsync(object payload)
        {
            try
            {
                var json = JsonConvert.SerializeObject(payload);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                
                await _client.PostAsync("https://xiv.naguya.tech/api/local/market/sync", content);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Failed to push market state.");
            }
        }

        public async Task<string> SearchItemsAsync(string query)
        {
            try
            {
                var response = await _client.GetAsync($"https://xiv.naguya.tech/api/market/search?q={Uri.EscapeDataString(query)}");
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Failed to search items.");
            }
            return null;
        }

        public async Task<bool> VerifyUserAsync(string name, string world)
        {
            try
            {
                var url = $"https://xiv.naguya.tech/api/local/verify?name={Uri.EscapeDataString(name)}&world={Uri.EscapeDataString(world)}";
                _log.Debug($"[Verify] Requesting: {url}");
                var response = await _client.GetAsync(url);
                _log.Debug($"[Verify] Response Code: {response.StatusCode}");
                
                var json = await response.Content.ReadAsStringAsync();
                _log.Debug($"[Verify] Response Content: {json}");

                if (response.IsSuccessStatusCode)
                {
                    var data = JsonConvert.DeserializeObject<dynamic>(json);
                    bool isVerified = (bool)(data?.verified ?? false);
                    string role = (string)(data?.role ?? "user");
                    CurrentUserRole = role;
                    _log.Debug($"[Verify] Parsed verified: {isVerified}, role: {role}");
                    return isVerified;
                }
                
                return false; 
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Failed to verify user.");
            }
            return false;
        }

        public async Task<string> FetchEventsAsync(string name, string world)
        {
            try
            {
                var response = await _client.GetAsync($"https://xiv.naguya.tech/api/events/custom?name={Uri.EscapeDataString(name)}&world={Uri.EscapeDataString(world)}");
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Failed to fetch events.");
            }
            return null;
        }

        public async Task WipeCalendarAsync(string name, string world)
        {
            try
            {
                var payload = new { name = name, world = world };
                var json = JsonConvert.SerializeObject(payload);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                await _client.PostAsync("https://xiv.naguya.tech/api/events/wipe", content);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Failed to wipe calendar");
            }
        }

        public async Task<string> FetchLodestoneEventsAsync()
        {
            try
            {
                var response = await _client.GetAsync("https://xiv.naguya.tech/api/events/lodestone");
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Failed to fetch lodestone events.");
            }
            return null;
        }

        public async Task<bool> DeleteCustomEventAsync(string id)
        {
            try
            {
                var response = await _client.DeleteAsync($"https://xiv.naguya.tech/api/events/custom?id={Uri.EscapeDataString(id)}");
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Failed to delete custom event.");
            }
            return false;
        }

        public async Task<string> ImportPartakeAsync(string url, string name, string world)
        {
            try
            {
                var payload = new { url = url, playerName = name, playerWorld = world };
                var json = JsonConvert.SerializeObject(payload);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                string endpoint = "https://xiv.naguya.tech/api/events/partake";
                if (url.Contains("partake.gg/venues/") || url.Contains("partake.gg/teams/"))
                {
                    endpoint = "https://xiv.naguya.tech/api/events/venues";
                }
                var response = await _client.PostAsync(endpoint, content);
                return await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Failed to import from partake.");
            }
            return null;
        }

        public async Task<string> SubscribeVenueAsync(string url, string name, string world)
        {
            try
            {
                var payload = new { url = url, playerName = name, playerWorld = world };
                var json = JsonConvert.SerializeObject(payload);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await _client.PostAsync("https://xiv.naguya.tech/api/events/venues", content);
                return await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Failed to subscribe venue.");
            }
            return null;
        }

        public async Task<bool> DeleteVenueAsync(string id, string name, string world)
        {
            try
            {
                var response = await _client.DeleteAsync($"https://xiv.naguya.tech/api/events/venues?id={Uri.EscapeDataString(id)}&name={Uri.EscapeDataString(name)}&world={Uri.EscapeDataString(world)}");
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Failed to delete venue.");
            }
            return false;
        }

        public async Task<string> SyncVenuesAsync(string name, string world)
        {
            try
            {
                var payload = new { playerName = name, playerWorld = world };
                var json = JsonConvert.SerializeObject(payload);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await _client.PostAsync("https://xiv.naguya.tech/api/events/venues/sync", content);
                return await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Failed to sync venues.");
            }
            return null;
        }

        public async Task<string> CreateCustomEventAsync(object payload)
        {
            try
            {
                var json = JsonConvert.SerializeObject(payload);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await _client.PostAsync("https://xiv.naguya.tech/api/events/custom", content);
                if (response.IsSuccessStatusCode)
                    return await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Failed to create custom event.");
            }
            return null;
        }

        public async Task<string> GetVenuesAsync(string name, string world)
        {
            try
            {
                var response = await _client.GetAsync($"https://xiv.naguya.tech/api/events/venues?name={Uri.EscapeDataString(name)}&world={Uri.EscapeDataString(world)}");
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Failed to fetch venues.");
            }
            return null;
        }
        public async Task<string> FetchMarketListingsAsync(string scope, uint itemId)
        {
            try
            {
                var response = await _client.GetAsync($"https://xiv.naguya.tech/api/market/listings?world={Uri.EscapeDataString(scope)}&itemId={itemId}");
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadAsStringAsync();
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Failed to fetch market listings.");
            }
            return null;
        }
    }
}
