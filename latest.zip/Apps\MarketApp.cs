using Dalamud.Bindings.ImGui;
using System;
using System.Numerics;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Component.GUI;
using Dalamud.Interface.Textures;
using Dalamud.Interface.Textures.TextureWraps;
using Dalamud.Game.Addon.Lifecycle;
using Dalamud.Game.Addon.Lifecycle.AddonArgTypes;
using Dalamud.Plugin;
using System.IO;

namespace XIVHubCompanion.Apps
{
    public class RouteStop
    {
        [JsonProperty("id")] public string id { get; set; } = string.Empty;
        [JsonProperty("itemId")] public int itemId { get; set; }
        [JsonProperty("itemName")] public string itemName { get; set; } = string.Empty;
        [JsonProperty("itemIcon")] public string itemIcon { get; set; } = string.Empty;
        [JsonProperty("world")] public string world { get; set; } = string.Empty;
        [JsonProperty("dc")] public string dc { get; set; } = string.Empty;
        [JsonProperty("retainer")] public string retainer { get; set; } = string.Empty;
        [JsonProperty("quantity")] public int quantity { get; set; }
        [JsonProperty("pricePerUnit")] public int pricePerUnit { get; set; }
        [JsonProperty("total")] public int total { get; set; }
        [JsonProperty("hq")] public bool? hq { get; set; }
        [JsonProperty("checked")] public bool checkedState { get; set; }
        [JsonProperty("resaleValue")] public int? resaleValue { get; set; }
        [JsonProperty("excessQty")] public int? excessQty { get; set; }
    }

    public class DestinationGroup
    {
        [JsonProperty("dc")] public string dc { get; set; } = string.Empty;
        [JsonProperty("world")] public string world { get; set; } = string.Empty;
        [JsonProperty("stops")] public List<RouteStop> stops { get; set; } = new List<RouteStop>();
        [JsonProperty("totalCost")] public int totalCost { get; set; }
    }

    public class CartItem
    {
        [JsonProperty("id")] public int id { get; set; }
        [JsonProperty("name")] public string name { get; set; } = string.Empty;
        [JsonProperty("icon")] public string icon { get; set; } = string.Empty;
        [JsonProperty("quantity")] public int quantity { get; set; }
        [JsonProperty("hq")] public bool? hq { get; set; }
        [JsonProperty("canBeHq")] public bool? canBeHq { get; set; }
    }

    public class MarketFavorite
    {
        [JsonProperty("id")] public int id { get; set; }
        [JsonProperty("name")] public string name { get; set; } = string.Empty;
        [JsonProperty("icon")] public string icon { get; set; } = string.Empty;
    }

    public class MarketSearchItem
    {
        [JsonProperty("id")] public int id { get; set; }
        [JsonProperty("name")] public string name { get; set; } = string.Empty;
        [JsonProperty("icon")] public string icon { get; set; } = string.Empty;
        [JsonProperty("ilvl")] public int? ilvl { get; set; }
        [JsonProperty("canBeHq")] public bool? canBeHq { get; set; }
    }

    public class MarketListing
    {
        [JsonProperty("pricePerUnit")] public int pricePerUnit { get; set; }
        [JsonProperty("quantity")] public int quantity { get; set; }
        [JsonProperty("hq")] public bool hq { get; set; }
        [JsonProperty("retainerName")] public string retainerName { get; set; } = string.Empty;
        [JsonProperty("total")] public int total { get; set; }
        [JsonProperty("worldName")] public string worldName { get; set; } = string.Empty;
    }

    public class MarketSale
    {
        [JsonProperty("pricePerUnit")] public int pricePerUnit { get; set; }
        [JsonProperty("quantity")] public int quantity { get; set; }
        [JsonProperty("buyerName")] public string buyerName { get; set; } = string.Empty;
        [JsonProperty("hq")] public bool hq { get; set; }
        [JsonProperty("timestamp")] public long timestamp { get; set; }
        [JsonProperty("worldName")] public string worldName { get; set; } = string.Empty;
    }

    public class MarketData
    {
        [JsonProperty("minPrice")] public int minPrice { get; set; }
        [JsonProperty("minPriceNQ")] public int minPriceNQ { get; set; }
        [JsonProperty("minPriceHQ")] public int minPriceHQ { get; set; }
        [JsonProperty("averagePrice")] public float averagePrice { get; set; }
        [JsonProperty("averagePriceNQ")] public float averagePriceNQ { get; set; }
        [JsonProperty("averagePriceHQ")] public float averagePriceHQ { get; set; }
        [JsonProperty("currentAveragePrice")] public float currentAveragePrice { get; set; }
        [JsonProperty("currentAveragePriceNQ")] public float currentAveragePriceNQ { get; set; }
        [JsonProperty("currentAveragePriceHQ")] public float currentAveragePriceHQ { get; set; }
        [JsonProperty("regularSaleVelocity")] public float regularSaleVelocity { get; set; }
        [JsonProperty("nqSaleVelocity")] public float nqSaleVelocity { get; set; }
        [JsonProperty("hqSaleVelocity")] public float hqSaleVelocity { get; set; }
        [JsonProperty("listings")] public List<MarketListing> listings { get; set; } = new();
        [JsonProperty("recentHistory")] public List<MarketSale> recentHistory { get; set; } = new();
        [JsonProperty("lastUploadTime")] public long lastUploadTime { get; set; }
    }

    public class MarketApp : IApp
    {
        public string Name => "Market";
        public string Icon => ((char)Dalamud.Interface.FontAwesomeIcon.Coins).ToString();

        private readonly IGameGui _gameGui;
        private readonly IAddonLifecycle _addonLifecycle;
        private readonly ITextureProvider _textureProvider;
        private readonly DataSender _sender;
        private readonly IPluginLog _log;
        private readonly Dalamud.Plugin.Services.IObjectTable _objectTable;

        private List<DestinationGroup> _destinations = new List<DestinationGroup>();
        private List<CartItem> _cart = new List<CartItem>();
        private Dictionary<string, MarketFavorite> _marketFavorites = new Dictionary<string, MarketFavorite>();
        
        private Dictionary<uint, ISharedImmediateTexture> _iconCache = new Dictionary<uint, ISharedImmediateTexture>();
        private bool _loggedReflection = false;
        private HashSet<string> _loggedMatches = new HashSet<string>();
        private HashSet<string> _seenTexts = new HashSet<string>();
        private HashSet<string> _activeRetainers = new HashSet<string>();
        
        private bool _hasPulledState = false;
        
        // Routing Settings
        private int _routePriority = 1;
        private int _routeStrategy = 0;
        private int _routeQuality = 0;
        private bool _allowServerTravel = true;
        private bool _allowDcTravel = true;
        private bool _isCalculating = false;
        
        // Search State
        private string _searchQuery = "";
        private List<MarketSearchItem> _searchResults = new List<MarketSearchItem>();
        private bool _isSearching = false;
        private bool _isRoutingEngineOpen = false;
        private string _activeCharacterName = string.Empty;

        // Detail View State
        private MarketSearchItem _selectedItem = null;
        private MarketData _marketData = null;
        private bool _isLoadingMarketData = false;
        private bool _detailShowHq = false;

        private IDalamudPluginInterface _pluginInterface;


        public MarketApp(IGameGui gameGui, IAddonLifecycle addonLifecycle, ITextureProvider textureProvider, DataSender sender, IPluginLog log, Dalamud.Plugin.Services.IObjectTable objectTable, IDalamudPluginInterface pluginInterface)
        {
            _gameGui = gameGui;
            _addonLifecycle = addonLifecycle;
            _textureProvider = textureProvider;
            _sender = sender;
            _log = log;
            _objectTable = objectTable;
            _pluginInterface = pluginInterface;

            _sender.OnServerEventReceived += OnServerEvent;
            
            _addonLifecycle.RegisterListener(AddonEvent.PostUpdate, "ItemSearchResult", OnItemSearchResultUpdate);
            _addonLifecycle.RegisterListener(AddonEvent.PostDraw, "ItemSearchResult", OnItemSearchResultUpdate);
            _addonLifecycle.RegisterListener(AddonEvent.PostUpdate, "ItemSearch", OnItemSearchResultUpdate);
            _addonLifecycle.RegisterListener(AddonEvent.PostUpdate, "ItemSearchResultCategory", OnItemSearchResultUpdate);
        }

        private void OnServerEvent(string eventType, string data)
        {
            if (eventType == "marketUpdate")
            {
                try {
                    var token = JToken.Parse(data);
                    if (token is JObject payload)
                    {
                        if (payload["data"] != null && payload["data"] is JObject innerData)
                        {
                            payload = innerData;
                        }

                        if (payload["cart"] != null) _cart = payload["cart"].ToObject<List<CartItem>>() ?? new List<CartItem>();
                        if (payload["marketFavorites"] != null) _marketFavorites = payload["marketFavorites"].ToObject<Dictionary<string, MarketFavorite>>() ?? new Dictionary<string, MarketFavorite>();
                        if (payload["route"] != null) _destinations = payload["route"].ToObject<List<DestinationGroup>>() ?? new List<DestinationGroup>();
                    }
                    UpdateActiveRetainers();
                } catch (Exception ex) {
                    _log.Error(ex, $"Failed to parse marketUpdate. Payload: {data}");
                }
            }
        }
        
        private void PushState()
        {
            if (string.IsNullOrEmpty(_activeCharacterName)) return;

            var payload = new
            {
                name = _activeCharacterName,
                cart = _cart,
                marketFavorites = _marketFavorites,
                route = _destinations
            };
            System.Threading.Tasks.Task.Run(() => _sender.PushMarketStateAsync(payload));
        }

        private async System.Threading.Tasks.Task PullInitialStateAsync()
        {
            try
            {
                var responseJson = await _sender.PullMarketStateAsync(_activeCharacterName);
                if (!string.IsNullOrEmpty(responseJson))
                {
                    var token = JToken.Parse(responseJson);
                    if (token is JObject obj && obj["data"] != null)
                    {
                        var data = obj["data"] as JObject;
                        if (data != null)
                        {
                            if (data["cart"] != null) _cart = data["cart"].ToObject<List<CartItem>>() ?? new List<CartItem>();
                            if (data["marketFavorites"] != null) _marketFavorites = data["marketFavorites"].ToObject<Dictionary<string, MarketFavorite>>() ?? new Dictionary<string, MarketFavorite>();
                            if (data["route"] != null) _destinations = data["route"].ToObject<List<DestinationGroup>>() ?? new List<DestinationGroup>();
                        }
                        UpdateActiveRetainers();
                    }
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Failed to pull initial state");
            }
        }
        
        private async System.Threading.Tasks.Task PerformSearchAsync(string query)
        {
            if (string.IsNullOrWhiteSpace(query)) return;
            try
            {
                _isSearching = true;
                _searchResults.Clear();
                var responseJson = await _sender.SearchItemsAsync(query);
                if (!string.IsNullOrEmpty(responseJson))
                {
                    var token = JToken.Parse(responseJson);
                    if (token is JObject obj && obj["results"] != null)
                    {
                        _searchResults = obj["results"].ToObject<List<MarketSearchItem>>() ?? new List<MarketSearchItem>();
                    }
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Search failed");
            }
            finally
            {
                _isSearching = false;
            }
        }

        private void SelectMarketItem(MarketSearchItem item)
        {
            _selectedItem = item;
            _marketData = null;
            _detailShowHq = item.canBeHq ?? false;
            System.Threading.Tasks.Task.Run(() => LoadMarketDataAsync(item.id));
        }

        private async System.Threading.Tasks.Task LoadMarketDataAsync(int itemId)
        {
            try
            {
                _isLoadingMarketData = true;
                string scope = ((_objectTable[0] as Dalamud.Game.ClientState.Objects.SubKinds.IPlayerCharacter)?.HomeWorld.Value.Name.ToString()) ?? "Cerberus";
                var responseJson = await _sender.FetchMarketListingsAsync(scope, (uint)itemId);
                if (!string.IsNullOrEmpty(responseJson))
                {
                    _marketData = JsonConvert.DeserializeObject<MarketData>(responseJson);
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Failed to load market data");
            }
            finally
            {
                _isLoadingMarketData = false;
            }
        }

        private void UpdateActiveRetainers()
        {
            _activeRetainers.Clear();
            if (_destinations == null) return;
            foreach (var dest in _destinations)
            {
                if (dest.stops == null) continue;
                foreach (var stop in dest.stops)
                {
                    if (!string.IsNullOrEmpty(stop.retainer))
                    {
                        _activeRetainers.Add(stop.retainer);
                    }
                }
            }
        }

        private unsafe void OnItemSearchResultUpdate(AddonEvent type, AddonArgs args)
        {
            try 
            {
                if (_activeRetainers.Count == 0) return;
                
                var addon = (AtkUnitBase*)args.Addon.Address;
                if (addon == null || addon->UldManager.NodeList == null) return;
                
                TraverseAndHighlight(addon->UldManager, _activeRetainers);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Crash in OnItemSearchResultUpdate");
            }
        }
        
        private unsafe void TraverseAndHighlight(AtkUldManager manager, HashSet<string> retainers)
        {
            if (manager.NodeList == null) return;

            for (int i = 0; i < manager.NodeListCount; i++)
            {
                var current = manager.NodeList[i];
                if (current == null) continue;
                if (current->Type == NodeType.Text)
                {
                    var textNode = (AtkTextNode*)current;
                    var text = textNode->NodeText.ToString();
                    
                    if (!string.IsNullOrWhiteSpace(text))
                    {
                        if (_seenTexts.Add(text))
                        {
                            _log.Info($"[UI-TEXT] {text}");
                        }

                        bool match = false;
                        foreach (var ret in retainers)
                        {
                            if (text.Contains(ret, StringComparison.OrdinalIgnoreCase))
                            {
                                match = true;
                                if (_loggedMatches.Add(ret))
                                {
                                    _log.Info($"SUCCESSFULLY MATCHED RETAINER: {ret} in text: '{text}'");
                                }
                                break;
                            }
                        }

                        if (match)
                        {
                            textNode->TextColor.R = 255; textNode->TextColor.G = 105; textNode->TextColor.B = 180; textNode->TextColor.A = 255;
                            textNode->EdgeColor.R = 255; textNode->EdgeColor.G = 105; textNode->EdgeColor.B = 180; textNode->EdgeColor.A = 255;
                            textNode->AtkResNode.Color.R = 255; textNode->AtkResNode.Color.G = 105; textNode->AtkResNode.Color.B = 180;
                        }
                        else
                        {
                            if (textNode->AtkResNode.Color.R == 255 && textNode->AtkResNode.Color.G == 105 && textNode->AtkResNode.Color.B == 180)
                            {
                                textNode->TextColor.R = 255; textNode->TextColor.G = 255; textNode->TextColor.B = 255; textNode->TextColor.A = 255;
                                textNode->EdgeColor.R = 0; textNode->EdgeColor.G = 0; textNode->EdgeColor.B = 0; textNode->EdgeColor.A = 255;
                                textNode->AtkResNode.Color.R = 255; textNode->AtkResNode.Color.G = 255; textNode->AtkResNode.Color.B = 255;
                            }
                        }
                    }
                }
                else if (current->Type == NodeType.Component || (int)current->Type >= 1000)
                {
                    var compNode = (AtkComponentNode*)current;
                    if (compNode->Component != null)
                    {
                        if (compNode->Component->UldManager.NodeList != null)
                        {
                            TraverseAndHighlight(compNode->Component->UldManager, retainers);
                        }
                    }
                }
            }
        }

        private ISharedImmediateTexture? GetIcon(uint iconId)
        {
            if (_iconCache.TryGetValue(iconId, out var tex)) return tex;
            
            try
            {
                var newTex = _textureProvider.GetFromGameIcon(new GameIconLookup(iconId));
                _iconCache[iconId] = newTex;
                return newTex;
            }
            catch (Exception ex) 
            { 
                _log.Error(ex, $"Failed to get icon {iconId}");
            }
            return null;
        }

        public void Draw()
        {
            try
            {
                var name = _objectTable[0]?.Name.ToString();
                if (!string.IsNullOrEmpty(name)) _activeCharacterName = name;
            }
            catch { }

            if (!_hasPulledState && !string.IsNullOrEmpty(_activeCharacterName))
            {
                _hasPulledState = true;
                System.Threading.Tasks.Task.Run(PullInitialStateAsync);
            }

            ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, new Vector2(12, 12) * PluginUI.AppScale);
            ImGuiWindowFlags childFlags = ImGuiWindowFlags.None;
            if (PluginUI.HideScrollbars) childFlags |= ImGuiWindowFlags.NoScrollbar;
            ImGui.BeginChild("MarketPaddedChild", ImGui.GetContentRegionAvail(), false, childFlags);
            
            if (_selectedItem != null)
            {
                DrawItemDetail();
            }
            else
            {
                if (ImGui.BeginTabBar("MarketTabs"))
                {
                    if (ImGui.BeginTabItem("Cart & Route"))
                    {
                        DrawCartAndRouteTab();
                        ImGui.EndTabItem();
                    }
                    if (ImGui.BeginTabItem("Favorites"))
                    {
                        DrawFavoritesTab();
                        ImGui.EndTabItem();
                    }
                    if (ImGui.BeginTabItem("Search"))
                    {
                        DrawSearchTab();
                        ImGui.EndTabItem();
                    }
                    ImGui.EndTabBar();
                }
            }
            
            ImGui.EndChild();
            ImGui.PopStyleVar();
        }
        
        private void DrawCartAndRouteTab()
        {
            ImGui.Dummy(new Vector2(0, 10) * PluginUI.AppScale);
            
            if (_cart.Count > 0)
            {
                if (UIHelper.DrawGarlondCollapsingHeader("hdr_route_cfg", "Routing Configuration", ref _isRoutingEngineOpen))
                {
                    DrawRoutingEngineUI();
                }
                ImGui.Dummy(new Vector2(0, 10) * PluginUI.AppScale);
                
                string btnText = _destinations.Count > 0 ? "Recalculate Route (Server)" : "Calculate Route (Server)";
                if (_isCalculating) btnText = "Calculating Route...";
                
                if (UIHelper.DrawGarlondCalculateButton("btn_calc", ImGui.GetCursorScreenPos(), new Vector2(ImGui.GetContentRegionAvail().X, 60f * PluginUI.AppScale), btnText, _isCalculating))
                {
                    if (!_isCalculating)
                    {
                        string homeWorld = ((_objectTable[0] as Dalamud.Game.ClientState.Objects.SubKinds.IPlayerCharacter)?.HomeWorld.Value.Name.ToString()) ?? "Cerberus";
                        System.Threading.Tasks.Task.Run(() => TriggerCalculateRoute(homeWorld));
                    }
                }
                ImGui.Dummy(new Vector2(0, 10) * PluginUI.AppScale);
            }

            if (_destinations.Count == 0 && _cart.Count == 0)
            {
                ImGui.TextColored(new Vector4(1, 1, 1, 0.5f), "No active routes or shopping cart items.");
                return;
            }

            if (_destinations.Count > 0)
            {
                Vector4 btnBg = new Vector4(0.12f, 0.12f, 0.14f, 1.0f);
                Vector4 btnHover = new Vector4(0.0f, 0.65f, 1.0f, 1.0f);
                Vector4 btnText = new Vector4(0.9f, 0.9f, 0.9f, 1.0f);
                Vector4 btnHoverText = new Vector4(1.0f, 1.0f, 1.0f, 1.0f);
                
                ImGui.TextColored(new Vector4(1, 1, 1, 0.7f), "ACTIVE SHOPPING ROUTE");
                if (UIHelper.DrawGarlondButton("btn_clear_route", ImGui.GetCursorScreenPos(), new Vector2(100, 25) * PluginUI.AppScale, "Clear Route", btnBg, btnHover, btnText, btnHoverText))
                {
                    _destinations.Clear();
                    UpdateActiveRetainers();
                    PushState();
                }
                ImGui.Dummy(new Vector2(0, 5) * PluginUI.AppScale);
                foreach (var dest in _destinations)
                {
                    DrawDestinationGroup(dest);
                }
            }
            
            if (_cart.Count > 0)
            {
                Vector4 btnBg = new Vector4(0.12f, 0.12f, 0.14f, 1.0f);
                Vector4 btnHover = new Vector4(0.0f, 0.65f, 1.0f, 1.0f);
                Vector4 btnText = new Vector4(0.9f, 0.9f, 0.9f, 1.0f);
                Vector4 btnHoverText = new Vector4(1.0f, 1.0f, 1.0f, 1.0f);
                
                ImGui.Dummy(new Vector2(0, 10) * PluginUI.AppScale);
                ImGui.TextColored(new Vector4(1, 1, 1, 0.7f), "SHOPPING CART");
                if (UIHelper.DrawGarlondButton("btn_clear_cart", ImGui.GetCursorScreenPos(), new Vector2(100, 25) * PluginUI.AppScale, "Clear Cart", btnBg, btnHover, btnText, btnHoverText))
                {
                    _cart.Clear();
                    PushState();
                }
                ImGui.Dummy(new Vector2(0, 5) * PluginUI.AppScale);
                
                foreach (var item in _cart.ToList())
                {
                    DrawCartItem(item);
                }
            }
        }
        
        private void DrawFavoritesTab()
        {
            ImGui.Dummy(new Vector2(0, 10) * PluginUI.AppScale);
            if (_marketFavorites.Count == 0)
            {
                ImGui.TextColored(new Vector4(1, 1, 1, 0.5f), "You have no favorites.");
                return;
            }
            
            foreach (var kvp in _marketFavorites.ToList())
            {
                DrawSearchOrFavoriteItem(kvp.Value.id, kvp.Value.name, kvp.Value.icon, true);
            }
        }
        
        private void DrawSearchTab()
        {
            Vector4 btnBg = new Vector4(0.12f, 0.12f, 0.14f, 1.0f);
            Vector4 btnHover = new Vector4(0.0f, 0.65f, 1.0f, 1.0f);
            Vector4 btnText = new Vector4(0.9f, 0.9f, 0.9f, 1.0f);
            Vector4 btnHoverText = new Vector4(1.0f, 1.0f, 1.0f, 1.0f);
            
            UIHelper.DrawGarlondInputText("search_input", ImGui.GetCursorScreenPos(), new Vector2(200, 25) * PluginUI.AppScale, ref _searchQuery, 200);
            ImGui.SameLine(0, 10);
            
            if (_isSearching)
            {
                ImGui.BeginDisabled();
                UIHelper.DrawGarlondButton("btn_searching", ImGui.GetCursorScreenPos(), new Vector2(100, 25) * PluginUI.AppScale, "Searching...", btnBg, btnBg, btnText, btnText);
                ImGui.EndDisabled();
            }
            else
            {
                if (UIHelper.DrawGarlondButton("btn_search", ImGui.GetCursorScreenPos(), new Vector2(100, 25) * PluginUI.AppScale, "Search", btnBg, btnHover, btnText, btnHoverText))
                {
                    System.Threading.Tasks.Task.Run(() => PerformSearchAsync(_searchQuery));
                }
            }
            
            ImGui.Dummy(new Vector2(0, 10) * PluginUI.AppScale);
            
            foreach (var item in _searchResults)
            {
                DrawSearchOrFavoriteItem(item.id, item.name, item.icon, false, item.canBeHq);
            }
        }

        private void DrawItemDetail()
        {
            var p = ImGui.GetCursorScreenPos();
            var w = ImGui.GetContentRegionAvail().X;

            Vector4 btnBg = new Vector4(0.12f, 0.12f, 0.14f, 1.0f);
            Vector4 btnHover = new Vector4(0.0f, 0.65f, 1.0f, 1.0f);
            Vector4 btnText = new Vector4(0.9f, 0.9f, 0.9f, 1.0f);
            Vector4 btnHoverText = new Vector4(1.0f, 1.0f, 1.0f, 1.0f);

            // Back Button & Name
            if (UIHelper.DrawGarlondButton("btn_back_detail", p, new Vector2(40, 25) * PluginUI.AppScale, "<", btnBg, btnHover, btnText, btnHoverText))
            {
                _selectedItem = null;
                _marketData = null;
                return;
            }

            ImGui.SameLine(0, 10 * PluginUI.AppScale);
            ImGui.SetCursorPosY(p.Y + 4 * PluginUI.AppScale);
            ImGui.TextColored(new Vector4(1, 1, 1, 1), _selectedItem.name);

            ImGui.Dummy(new Vector2(0, 10 * PluginUI.AppScale));

            if (_isLoadingMarketData)
            {
                ImGui.TextColored(new Vector4(0.6f, 0.6f, 0.6f, 1.0f), "Loading market data...");
                return;
            }

            if (_marketData == null)
            {
                ImGui.TextColored(new Vector4(1.0f, 0.3f, 0.3f, 1.0f), "Failed to load market data or item has no listings.");
                return;
            }

            // HQ Toggle if applicable
            if (_selectedItem.canBeHq == true)
            {
                var hqP = ImGui.GetCursorScreenPos();
                UIHelper.DrawGarlondRadioButtonWithText("det_nq", "NQ", ref _detailShowHq_int, 0);
                ImGui.SameLine(0, 15 * PluginUI.AppScale);
                UIHelper.DrawGarlondRadioButtonWithText("det_hq", "HQ", ref _detailShowHq_int, 1);
                _detailShowHq = _detailShowHq_int == 1;
                ImGui.Dummy(new Vector2(0, 10 * PluginUI.AppScale));
            }

            DrawPricesSummary();
            ImGui.Dummy(new Vector2(0, 10 * PluginUI.AppScale));
            DrawTrendSection();
            ImGui.Dummy(new Vector2(0, 10 * PluginUI.AppScale));
            DrawListingsTable();
            ImGui.Dummy(new Vector2(0, 10 * PluginUI.AppScale));
            DrawSalesTable();
        }

        private int _detailShowHq_int = 0; // State for radio buttons

        private void DrawPricesSummary()
        {
            var p = ImGui.GetCursorScreenPos();
            var w = ImGui.GetContentRegionAvail().X;
            var h = 60f * PluginUI.AppScale;

            UIHelper.DrawCard(p, new Vector2(w, h), new Vector4(0.12f, 0.12f, 0.13f, 1.0f), 6f, new Vector4(0.3f, 0.3f, 0.3f, 0.5f));
            
            float third = w / 3f;
            
            ImGui.SetCursorScreenPos(new Vector2(p.X + 10, p.Y + 10));
            ImGui.TextColored(new Vector4(0.6f, 0.6f, 0.6f, 1.0f), "Cheapest");
            ImGui.SetCursorScreenPos(new Vector2(p.X + 10, p.Y + 30));
            int minPrice = _detailShowHq ? _marketData.minPriceHQ : _marketData.minPriceNQ;
            ImGui.TextColored(new Vector4(1f, 1f, 1f, 1f), minPrice > 0 ? $"{minPrice:N0}" : "-");

            ImGui.SetCursorScreenPos(new Vector2(p.X + third + 10, p.Y + 10));
            ImGui.TextColored(new Vector4(0.6f, 0.6f, 0.6f, 1.0f), "Avg Sale");
            ImGui.SetCursorScreenPos(new Vector2(p.X + third + 10, p.Y + 30));
            float avgPrice = _detailShowHq ? _marketData.averagePriceHQ : _marketData.averagePriceNQ;
            ImGui.TextColored(new Vector4(1f, 1f, 1f, 1f), avgPrice > 0 ? $"{avgPrice:N0}" : "-");

            ImGui.SetCursorScreenPos(new Vector2(p.X + third * 2 + 10, p.Y + 10));
            ImGui.TextColored(new Vector4(0.6f, 0.6f, 0.6f, 1.0f), "Sold/Day");
            ImGui.SetCursorScreenPos(new Vector2(p.X + third * 2 + 10, p.Y + 30));
            float vel = _detailShowHq ? _marketData.hqSaleVelocity : _marketData.nqSaleVelocity;
            ImGui.TextColored(new Vector4(1f, 1f, 1f, 1f), $"{vel:F1}");

            ImGui.SetCursorScreenPos(new Vector2(p.X, p.Y + h));
        }

        private void DrawTrendSection()
        {
            var p = ImGui.GetCursorScreenPos();
            var w = ImGui.GetContentRegionAvail().X;
            var h = 80f * PluginUI.AppScale;

            ImGui.TextColored(new Vector4(1f, 0.41f, 0.71f, 1f), "Price history");
            ImGui.Dummy(new Vector2(0, 5 * PluginUI.AppScale));

            var graphP = ImGui.GetCursorScreenPos();
            UIHelper.DrawCard(graphP, new Vector2(w, h), new Vector4(0.12f, 0.12f, 0.13f, 1.0f), 6f, new Vector4(0.3f, 0.3f, 0.3f, 0.5f));

            var sales = _marketData.recentHistory.Where(s => s.hq == _detailShowHq).ToList();
            if (sales.Count >= 2)
            {
                var values = sales.Select(s => (float)s.pricePerUnit).ToArray();
                Array.Reverse(values); // Chronological
                Sparkline.Draw(graphP, graphP + new Vector2(w, h), values, new Vector4(1f, 0.41f, 0.71f, 1f), new Vector4(1f, 0.41f, 0.71f, 0.18f));
            }
            else
            {
                var text = "Not enough data";
                var size = ImGui.CalcTextSize(text);
                ImGui.SetCursorScreenPos(new Vector2(graphP.X + (w - size.X) / 2, graphP.Y + (h - size.Y) / 2));
                ImGui.TextColored(new Vector4(0.5f, 0.5f, 0.5f, 1f), text);
            }

            ImGui.SetCursorScreenPos(new Vector2(p.X, graphP.Y + h));
        }

        private void DrawListingsTable()
        {
            ImGui.TextColored(new Vector4(1f, 0.41f, 0.71f, 1f), "Current listings");
            ImGui.Dummy(new Vector2(0, 5 * PluginUI.AppScale));
            
            var listings = _marketData.listings.Where(l => l.hq == _detailShowHq).Take(50).ToList();
            if (listings.Count == 0)
            {
                ImGui.TextColored(new Vector4(0.5f, 0.5f, 0.5f, 1f), "No listings.");
                return;
            }

            if (ImGui.BeginTable("market_listings_table", 4, ImGuiTableFlags.BordersInnerH | ImGuiTableFlags.SizingStretchProp))
            {
                ImGui.TableSetupColumn("Price");
                ImGui.TableSetupColumn("Qty");
                ImGui.TableSetupColumn("World");
                ImGui.TableSetupColumn("Retainer");
                ImGui.TableHeadersRow();

                foreach (var l in listings)
                {
                    ImGui.TableNextRow();
                    ImGui.TableNextColumn();
                    ImGui.TextColored(new Vector4(0.94f, 0.78f, 0.35f, 1f), $"{l.pricePerUnit:N0}");
                    ImGui.TableNextColumn();
                    ImGui.TextColored(new Vector4(0.8f, 0.8f, 0.8f, 1f), $"x{l.quantity}");
                    ImGui.TableNextColumn();
                    ImGui.TextColored(new Vector4(0.9f, 0.9f, 0.9f, 1f), l.worldName);
                    ImGui.TableNextColumn();
                    ImGui.TextColored(new Vector4(0.7f, 0.7f, 0.7f, 1f), l.retainerName);
                }
                ImGui.EndTable();
            }
        }

        private void DrawSalesTable()
        {
            ImGui.TextColored(new Vector4(1f, 0.41f, 0.71f, 1f), "Recent sales");
            ImGui.Dummy(new Vector2(0, 5 * PluginUI.AppScale));
            
            var sales = _marketData.recentHistory.Where(s => s.hq == _detailShowHq).Take(50).ToList();
            if (sales.Count == 0)
            {
                ImGui.TextColored(new Vector4(0.5f, 0.5f, 0.5f, 1f), "No recent sales.");
                return;
            }

            if (ImGui.BeginTable("market_sales_table", 4, ImGuiTableFlags.BordersInnerH | ImGuiTableFlags.SizingStretchProp))
            {
                ImGui.TableSetupColumn("Price");
                ImGui.TableSetupColumn("Qty");
                ImGui.TableSetupColumn("World");
                ImGui.TableSetupColumn("Buyer");
                ImGui.TableHeadersRow();

                foreach (var s in sales)
                {
                    ImGui.TableNextRow();
                    ImGui.TableNextColumn();
                    ImGui.TextColored(new Vector4(0.94f, 0.78f, 0.35f, 1f), $"{s.pricePerUnit:N0}");
                    ImGui.TableNextColumn();
                    ImGui.TextColored(new Vector4(0.8f, 0.8f, 0.8f, 1f), $"x{s.quantity}");
                    ImGui.TableNextColumn();
                    ImGui.TextColored(new Vector4(0.9f, 0.9f, 0.9f, 1f), s.worldName);
                    ImGui.TableNextColumn();
                    ImGui.TextColored(new Vector4(0.7f, 0.7f, 0.7f, 1f), s.buyerName);
                }
                ImGui.EndTable();
            }
        }
        
        private void DrawSearchOrFavoriteItem(int id, string name, string icon, bool isFavoriteTab, bool? canBeHq = false)
        {
            var p = ImGui.GetCursorScreenPos();
            var w = ImGui.GetContentRegionAvail().X;
            var h = 50f;
            
            UIHelper.DrawCard(p, new Vector2(w, h), new Vector4(0.12f, 0.12f, 0.13f, 1.0f), 6f, new Vector4(0.3f, 0.3f, 0.3f, 0.5f));

            ImGui.SetCursorScreenPos(p);
            ImGui.PushID($"item_card_{id}");
            if (ImGui.InvisibleButton("card", new Vector2(w - 180, h)))
            {
                var item = new MarketSearchItem { id = id, name = name, icon = icon, canBeHq = canBeHq };
                SelectMarketItem(item);
            }
            ImGui.PopID();

            uint iconId = 0;
            if (!string.IsNullOrEmpty(icon))
            {
                var parts = icon.Split('/');
                var filename = parts[parts.Length - 1].Replace(".png", "");
                uint.TryParse(filename, out iconId);
            }
            if (iconId != 0)
            {
                dynamic texWrap = GetIcon(iconId)?.GetWrapOrDefault();
                if (texWrap != null)
                {
                    ImGui.SetCursorScreenPos(new Vector2(p.X + 12, p.Y + 9));
                    try { ImGui.Image(texWrap.Handle, new Vector2(32, 32) * PluginUI.AppScale); } 
                    catch (Exception) { }
                }
            }

            ImGui.SetCursorScreenPos(new Vector2(p.X + 55, p.Y + 16));
            ImGui.TextColored(new Vector4(1f, 1f, 1f, 1f), name);
            
            // Buttons on the right
            bool isFav = _marketFavorites.ContainsKey(id.ToString());
            
            Vector4 btnBg = new Vector4(0.12f, 0.12f, 0.14f, 1.0f);
            Vector4 btnHover = new Vector4(0.0f, 0.65f, 1.0f, 1.0f);
            Vector4 btnText = new Vector4(0.9f, 0.9f, 0.9f, 1.0f);
            Vector4 btnHoverText = new Vector4(1.0f, 1.0f, 1.0f, 1.0f);
            
            float rightEdge = p.X + w;
            
            ImGui.PushID(id);
            if (UIHelper.DrawGarlondButton("fav", new Vector2(Math.Max(p.X + 200, rightEdge - 160), p.Y + 12), new Vector2(75, 25) * PluginUI.AppScale, isFav ? "Unfavorite" : "Favorite", btnBg, btnHover, btnText, btnHoverText))
            {
                if (isFav) _marketFavorites.Remove(id.ToString());
                else _marketFavorites[id.ToString()] = new MarketFavorite { id = id, name = name, icon = icon };
                PushState();
            }
            
            if (UIHelper.DrawGarlondButton("cart", new Vector2(Math.Max(p.X + 280, rightEdge - 80), p.Y + 12), new Vector2(70, 25) * PluginUI.AppScale, "Add", btnBg, btnHover, btnText, btnHoverText))
            {
                var existing = _cart.FirstOrDefault(c => c.id == id);
                if (existing != null)
                {
                    existing.quantity++;
                }
                else
                {
                    _cart.Add(new CartItem { id = id, name = name, icon = icon, quantity = 1, canBeHq = canBeHq });
                }
                PushState();
            }
            ImGui.PopID();

            ImGui.SetCursorScreenPos(new Vector2(p.X, p.Y + h));
            ImGui.Dummy(new Vector2(0, 5) * PluginUI.AppScale);
        }

        private void DrawRoutingEngineUI()
        {
            ImGui.PushStyleColor(ImGuiCol.ChildBg, new Vector4(0.05f, 0.05f, 0.07f, 0.8f));
            ImGui.PushStyleVar(ImGuiStyleVar.ChildRounding, 8f);
            ImGui.BeginChild("RoutingEngineUI", new Vector2(-1, 150) * PluginUI.AppScale, true, ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse);

            if (ImGui.BeginTable("routingEngineGrid", 4, ImGuiTableFlags.BordersInnerV | ImGuiTableFlags.SizingStretchProp))
            {
                ImGui.TableSetupColumn("Priority", ImGuiTableColumnFlags.WidthStretch);
                ImGui.TableSetupColumn("Strategy", ImGuiTableColumnFlags.WidthStretch);
                ImGui.TableSetupColumn("Quality", ImGuiTableColumnFlags.WidthStretch);
                ImGui.TableSetupColumn("Travel", ImGuiTableColumnFlags.WidthStretch);
                
                ImGui.TableNextRow();
                ImGui.TableNextColumn();
                
                ImGui.BeginGroup();
                ImGui.TextColored(new Vector4(0.6f, 0.6f, 0.6f, 1f), "Priority");
                ImGui.Dummy(new Vector2(0, 5) * PluginUI.AppScale);
                UIHelper.DrawGarlondRadioButtonWithText("route_pri_0", "Fastest", ref _routePriority, 0);
                UIHelper.DrawGarlondRadioButtonWithText("route_pri_1", "Balanced", ref _routePriority, 1);
                UIHelper.DrawGarlondRadioButtonWithText("route_pri_2", "Cheapest", ref _routePriority, 2);
                ImGui.EndGroup();

                ImGui.TableNextColumn();
                ImGui.BeginGroup();
                ImGui.TextColored(new Vector4(0.6f, 0.6f, 0.6f, 1f), "Strategy");
                ImGui.Dummy(new Vector2(0, 5) * PluginUI.AppScale);
                UIHelper.DrawGarlondRadioButtonWithText("route_strat_0", "Strict Qty", ref _routeStrategy, 0);
                UIHelper.DrawGarlondRadioButtonWithText("route_strat_1", "Smart Bulk", ref _routeStrategy, 1);
                ImGui.EndGroup();

                ImGui.TableNextColumn();
                ImGui.BeginGroup();
                ImGui.TextColored(new Vector4(0.6f, 0.6f, 0.6f, 1f), "Quality");
                ImGui.Dummy(new Vector2(0, 5) * PluginUI.AppScale);
                UIHelper.DrawGarlondRadioButtonWithText("route_qual_0", "Keep HQ", ref _routeQuality, 0);
                UIHelper.DrawGarlondRadioButtonWithText("route_qual_1", "Force HQ", ref _routeQuality, 1);
                UIHelper.DrawGarlondRadioButtonWithText("route_qual_2", "Ignore HQ", ref _routeQuality, 2);
                ImGui.EndGroup();

                ImGui.TableNextColumn();
                ImGui.BeginGroup();
                ImGui.TextColored(new Vector4(0.6f, 0.6f, 0.6f, 1f), "Travel");
                ImGui.Dummy(new Vector2(0, 5) * PluginUI.AppScale);
                UIHelper.DrawGarlondSwitchWithText("chk_server_travel", "Allow Server Travel", ref _allowServerTravel);
                if (!_allowServerTravel) _allowDcTravel = false;
                
                ImGui.Dummy(new Vector2(0, 2) * PluginUI.AppScale);
                UIHelper.DrawGarlondSwitchWithText("chk_dc_travel", "Allow DC Travel", ref _allowDcTravel);
                ImGui.EndGroup();

                ImGui.EndTable();
            }
            
            ImGui.EndChild();
            ImGui.PopStyleVar();
            ImGui.PopStyleColor();
        }

        private async System.Threading.Tasks.Task TriggerCalculateRoute(string homeWorld)
        {
            if (_cart.Count == 0) return;

            try
            {
                _isCalculating = true;
                string priority = _routePriority == 0 ? "fastest" : _routePriority == 1 ? "balanced" : "cheapest";
                string strategy = _routeStrategy == 0 ? "strict" : "bulk";
                string quality = _routeQuality == 0 ? "keep" : _routeQuality == 1 ? "force_hq" : "ignore_hq";
                
                var responseJson = await _sender.CalculateRouteAsync(new {
                    cart = _cart,
                    homeWorld = homeWorld,
                    searchScope = homeWorld,
                    routePriority = priority,
                    routeStrategy = strategy,
                    routeQuality = quality,
                    allowServerTravel = _allowServerTravel,
                    allowDcTravel = _allowDcTravel
                });

                if (!string.IsNullOrEmpty(responseJson))
                {
                    var token = JToken.Parse(responseJson);
                    if (token is JObject obj && obj["finalDestinations"] != null)
                    {
                        var dests = obj["finalDestinations"].ToObject<List<DestinationGroup>>();
                        _destinations = dests?.Where(d => !string.IsNullOrWhiteSpace(d.dc) && !string.IsNullOrWhiteSpace(d.world)).ToList() ?? new List<DestinationGroup>();
                        UpdateActiveRetainers();
                        PushState();
                    }
                }
            }
            catch (Exception ex)
            {
                _log.Error($"Failed to trigger route calculation: {ex}");
            }
            finally
            {
                _isCalculating = false;
            }
        }

        private void DrawDestinationGroup(DestinationGroup dest)
        {
            ImGui.PushFont(Dalamud.Interface.UiBuilder.IconFont);
            ImGui.TextColored(new Vector4(0.13f, 0.77f, 0.36f, 1.0f), "\uf0ac");
            ImGui.PopFont();
            ImGui.SameLine();
            ImGui.TextColored(new Vector4(0.9f, 0.9f, 0.9f, 1.0f), $"{dest.world} [{dest.dc}]");

            var p = ImGui.GetCursorScreenPos();
            var w = ImGui.GetContentRegionAvail().X;
            float rightEdge = p.X + w;
            
            string destTotalText = $"{dest.totalCost:N0} Gil";
            var destTotalSize = ImGui.CalcTextSize(destTotalText);
            
            ImGui.SetCursorScreenPos(new Vector2(rightEdge - destTotalSize.X - 10f, p.Y - 20));
            ImGui.TextColored(new Vector4(0.94f, 0.78f, 0.35f, 1f), destTotalText);
            
            ImGui.SetCursorScreenPos(p);
            ImGui.Dummy(new Vector2(0, 5) * PluginUI.AppScale);

            foreach (var stop in dest.stops)
            {
                DrawRouteStop(stop);
                ImGui.Dummy(new Vector2(0, 5) * PluginUI.AppScale);
            }
        }

        private void DrawRouteStop(RouteStop stop)
        {
            var p = ImGui.GetCursorScreenPos();
            var w = ImGui.GetContentRegionAvail().X;
            var h = 54f;
            
            UIHelper.DrawCard(p, new Vector2(w, h), new Vector4(0.12f, 0.12f, 0.13f, 1.0f), 6f, new Vector4(0.3f, 0.3f, 0.3f, 0.5f));

            ImGui.SetCursorScreenPos(new Vector2(p.X + 12, p.Y + 17));
            bool isChecked = stop.checkedState;
            ImGui.PushID(stop.id);
            if (UIHelper.DrawGarlondCheckbox("chk", ImGui.GetCursorScreenPos(), ref isChecked))
            {
                stop.checkedState = isChecked;
                _sender.SendActionAsync(new { action = "TOGGLE_STOP", itemId = stop.itemId, @checked = isChecked });
                PushState();
            }
            ImGui.PopID();
            
            uint iconId = 0;
            if (!string.IsNullOrEmpty(stop.itemIcon))
            {
                var match = System.Text.RegularExpressions.Regex.Match(stop.itemIcon, @"(\d+)\.png");
                if (match.Success)
                {
                    uint.TryParse(match.Groups[1].Value, out iconId);
                }
                else
                {
                    var parts = stop.itemIcon.Split('/');
                    var filename = parts[parts.Length - 1].Replace(".png", "");
                    uint.TryParse(filename, out iconId);
                }
            }
            if (iconId != 0)
            {
                dynamic texWrap = GetIcon(iconId)?.GetWrapOrDefault();
                if (texWrap != null)
                {
                    ImGui.SetCursorScreenPos(new Vector2(p.X + 45, p.Y + 11));
                    try { 
                        ImGui.Image(texWrap.Handle, new Vector2(32, 32) * PluginUI.AppScale); 
                    } 
                    catch (Exception ex) { 
                        if (!_loggedReflection) {
                            _loggedReflection = true;
                            _log.Error(ex, "Failed to draw Image");
                        }
                    }
                }
            }

            ImGui.SetCursorScreenPos(new Vector2(p.X + 85, p.Y + 10));
            ImGui.TextColored(new Vector4(1f, 1f, 1f, 1f), stop.itemName);
            
            if (stop.hq.HasValue && stop.hq.Value)
            {
                ImGui.SameLine();
                ImGui.TextColored(new Vector4(0.13f, 0.83f, 0.93f, 1f), "\uE03C");
            }
            
            ImGui.SetCursorScreenPos(new Vector2(p.X + 85, p.Y + 29));
            ImGui.SetWindowFontScale(0.85f);
            ImGui.TextColored(new Vector4(0.6f, 0.65f, 0.7f, 1f), $"Retainer: {stop.retainer}");
            ImGui.SetWindowFontScale(1.0f);

            string buyText = $"Buy {stop.quantity} @ {stop.pricePerUnit:N0}";
            string totalText = $"{stop.total:N0} Gil";
            
            float rightEdge = p.X + w;
            
            float btnWidth = PluginUI.Scaled(70f);
            float btnX = rightEdge - btnWidth - 10f;
            
            var totalSize = ImGui.CalcTextSize(totalText);
            float totalX = btnX - totalSize.X - 15f;
            
            var buySize = ImGui.CalcTextSize(buyText);
            float buyX = totalX - buySize.X - 25f;
            
            ImGui.SetCursorScreenPos(new Vector2(buyX, p.Y + 18));
            ImGui.TextColored(new Vector4(0.9f, 0.9f, 0.9f, 1f), buyText);

            ImGui.SetCursorScreenPos(new Vector2(totalX, p.Y + 18));
            ImGui.TextColored(new Vector4(0.94f, 0.78f, 0.35f, 1f), totalText);

            if (UIHelper.DrawGarlondWarningButton($"btn_soldout_{stop.id}", new Vector2(btnX, p.Y + 16), new Vector2(btnWidth, 22 * PluginUI.AppScale), "Sold Out"))
            {
                // Trigger automatic recalculation
                string homeWorld = ((_objectTable[0] as Dalamud.Game.ClientState.Objects.SubKinds.IPlayerCharacter)?.HomeWorld.Value.Name.ToString()) ?? "Cerberus";
                System.Threading.Tasks.Task.Run(() => TriggerCalculateRoute(homeWorld));
            }

            ImGui.SetCursorScreenPos(new Vector2(p.X, p.Y + h));
        }

        private void DrawCartItem(CartItem item)
        {
            var p = ImGui.GetCursorScreenPos();
            var w = ImGui.GetContentRegionAvail().X;
            var h = 50f;
            
            UIHelper.DrawCard(p, new Vector2(w, h), new Vector4(0.12f, 0.12f, 0.13f, 1.0f), 6f, new Vector4(0.3f, 0.3f, 0.3f, 0.5f));

            uint iconId = 0;
            if (!string.IsNullOrEmpty(item.icon))
            {
                var parts = item.icon.Split('/');
                var filename = parts[parts.Length - 1].Replace(".png", "");
                uint.TryParse(filename, out iconId);
            }
            if (iconId != 0)
            {
                dynamic texWrap = GetIcon(iconId)?.GetWrapOrDefault();
                if (texWrap != null)
                {
                    ImGui.SetCursorScreenPos(new Vector2(p.X + 12, p.Y + 9));
                    try { ImGui.Image(texWrap.Handle, new Vector2(32, 32) * PluginUI.AppScale); } 
                    catch (Exception ex) { 
                        if (!_loggedReflection) {
                            _loggedReflection = true;
                            _log.Error(ex, "Failed to draw Image in Cart");
                        }
                    }
                }
            }

            ImGui.SetCursorScreenPos(new Vector2(p.X + 55, p.Y + 16));
            ImGui.TextColored(new Vector4(1f, 1f, 1f, 1f), item.name);
            
            if (item.hq.HasValue && item.hq.Value)
            {
                ImGui.SameLine();
                ImGui.TextColored(new Vector4(0.13f, 0.83f, 0.93f, 1f), "\uE03C");
            }
            
            string qtyText = $"x{item.quantity}";
            float qtyWidth = ImGui.CalcTextSize(qtyText).X;

            float rightEdge = p.X + w;
            Vector4 btnBg = new Vector4(0.12f, 0.12f, 0.14f, 1.0f);
            Vector4 btnHover = new Vector4(0.0f, 0.65f, 1.0f, 1.0f);
            Vector4 btnText = new Vector4(0.9f, 0.9f, 0.9f, 1.0f);
            Vector4 btnHoverText = new Vector4(1.0f, 1.0f, 1.0f, 1.0f);

            ImGui.PushID(item.id);
            if (UIHelper.DrawGarlondButton("rem", new Vector2(Math.Max(p.X + 200, rightEdge - 100 - qtyWidth), p.Y + 12), new Vector2(25, 25) * PluginUI.AppScale, "-", btnBg, btnHover, btnText, btnHoverText))
            {
                item.quantity--;
                if (item.quantity <= 0) _cart.Remove(item);
                PushState();
            }
            ImGui.SetCursorScreenPos(new Vector2(Math.Max(p.X + 230, rightEdge - 70 - qtyWidth), p.Y + 16));
            ImGui.TextColored(new Vector4(0.94f, 0.78f, 0.35f, 1f), qtyText);
            
            if (UIHelper.DrawGarlondButton("add", new Vector2(Math.Max(p.X + 260, rightEdge - 40 - qtyWidth), p.Y + 12), new Vector2(25, 25) * PluginUI.AppScale, "+", btnBg, btnHover, btnText, btnHoverText))
            {
                item.quantity++;
                PushState();
            }
            ImGui.PopID();

            ImGui.SetCursorScreenPos(new Vector2(p.X, p.Y + h));
        }

        public void Dispose()
        {
            _sender.OnServerEventReceived -= OnServerEvent;
            _addonLifecycle.UnregisterListener(AddonEvent.PostUpdate, "ItemSearchResult", OnItemSearchResultUpdate);
            _addonLifecycle.UnregisterListener(AddonEvent.PostDraw, "ItemSearchResult", OnItemSearchResultUpdate);
            _addonLifecycle.UnregisterListener(AddonEvent.PostUpdate, "ItemSearch", OnItemSearchResultUpdate);
            _addonLifecycle.UnregisterListener(AddonEvent.PostUpdate, "ItemSearchResultCategory", OnItemSearchResultUpdate);
            
            _iconCache.Clear();
        }
    }
}
