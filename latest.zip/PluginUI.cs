using Dalamud.Bindings.ImGui;
using System;
using System.Numerics;
using System.Collections.Generic;
using XIVHubCompanion.Apps;
using Dalamud.Plugin;
using Dalamud.Interface.Textures;
using Dalamud.Interface.Textures.TextureWraps;

namespace XIVHubCompanion
{
    public class PluginUI : IDisposable
    {
        private Configuration configuration;
        private DataSender sender;
        private IDalamudPluginInterface pluginInterface;
        private bool settingsVisible = false;
        private Dalamud.Plugin.Services.IObjectTable _objectTable;

        private bool _isVerified = true;
        private bool _verificationChecked = false;
        private bool _isVerifying = false;

        private List<IApp> _apps = new List<IApp>();
        private IApp _selectedApp;
        private int _selectedCharacterIndex = 0;
        
        private List<Action> _flyoutQueue = new List<Action>();      
        private ConstellationBackground _constellation = new ConstellationBackground();

        public bool SettingsVisible
        {
            get { return settingsVisible; }
            set { settingsVisible = value; }
        }
        
        private readonly Dalamud.Plugin.Services.IPluginLog _log;
        private readonly Dalamud.Plugin.Services.ITextureProvider _textureProvider;

        private Dictionary<string, ISharedImmediateTexture> _sidebarIconCache = new Dictionary<string, ISharedImmediateTexture>();

        public PluginUI(Configuration configuration, DataSender sender, Dalamud.Plugin.Services.IGameGui gameGui, Dalamud.Plugin.Services.IAddonLifecycle addonLifecycle, Dalamud.Plugin.Services.ITextureProvider textureProvider, IDalamudPluginInterface pluginInterface, Dalamud.Plugin.Services.IPluginLog log, Dalamud.Plugin.Services.IObjectTable objectTable)
        {
            this.configuration = configuration;
            this.sender = sender;
            this.pluginInterface = pluginInterface;
            this._log = log;
            this._objectTable = objectTable;
            this._textureProvider = textureProvider;

            _apps.Add(new MarketApp(gameGui, addonLifecycle, textureProvider, sender, _log, objectTable, pluginInterface));
            _apps.Add(new GatheringApp(sender));
            _apps.Add(new CraftingApp(sender));
            _apps.Add(new CollectionApp(sender));
            _apps.Add(new RoutinesApp());
            _apps.Add(new EventsApp(sender, objectTable, _log, textureProvider, pluginInterface));
            _apps.Add(new RaidPlannerApp());
            
            _selectedApp = _apps[0];
        }

        public void Dispose()
        {
            foreach (var app in _apps)
            {
                app.Dispose();
            }
        }

        private void DrawGarlondFrame(ImDrawListPtr bgDrawList, Vector2 outerPos, Vector2 outerSize)
        {
            // Garlond Ironworks Color Palette
            uint gunmetal = UIHelper.Vec4ToU32(new Vector4(0.17f, 0.17f, 0.19f, 1.0f));
            uint darkIron = UIHelper.Vec4ToU32(new Vector4(0.12f, 0.12f, 0.14f, 1.0f));
            uint edgeHighlight = UIHelper.Vec4ToU32(new Vector4(0.3f, 0.3f, 0.35f, 1.0f));
            uint ceruleumBlue = UIHelper.Vec4ToU32(new Vector4(0.0f, 0.65f, 1.0f, 1.0f));
            uint ceruleumGlow = UIHelper.Vec4ToU32(new Vector4(0.0f, 0.65f, 1.0f, 0.3f));
            uint hazardYellow = UIHelper.Vec4ToU32(new Vector4(0.9f, 0.8f, 0.0f, 1.0f));
            uint hazardBlack = UIHelper.Vec4ToU32(new Vector4(0.05f, 0.05f, 0.05f, 1.0f));
            uint rivetColor = UIHelper.Vec4ToU32(new Vector4(0.08f, 0.08f, 0.09f, 1.0f));
            
            // Draw chassis rects to simulate chamfers/bevels safely using multiple AddRects and AddRectFilled
            bgDrawList.AddRectFilled(outerPos, outerPos + outerSize, gunmetal, Scaled(12f));
            bgDrawList.AddRect(outerPos, outerPos + outerSize, edgeHighlight, Scaled(12f), 0, Scaled(2f));
            
            // Inner rim (symmetric 21px distance from edges to match original visual ratio)
            Vector2 innerPos = outerPos + Scaled(new Vector2(21, 21));
            Vector2 innerSize = outerSize - Scaled(new Vector2(42, 42));
            
            bgDrawList.AddRectFilled(innerPos, innerPos + innerSize, darkIron, Scaled(4f));
            
            bgDrawList.AddRect(innerPos, innerPos + innerSize, ceruleumBlue, Scaled(4f), 0, Scaled(2f)); // Ceruleum track
            
            float nodeRadius = Scaled(6f);
            bgDrawList.AddCircleFilled(innerPos, nodeRadius, ceruleumBlue);
            bgDrawList.AddCircleFilled(innerPos, nodeRadius + Scaled(4f), ceruleumGlow);
            
            bgDrawList.AddCircleFilled(new Vector2(innerPos.X + innerSize.X, innerPos.Y), nodeRadius, ceruleumBlue);
            bgDrawList.AddCircleFilled(new Vector2(innerPos.X + innerSize.X, innerPos.Y), nodeRadius + Scaled(4f), ceruleumGlow);
            
            bgDrawList.AddCircleFilled(new Vector2(innerPos.X, innerPos.Y + innerSize.Y), nodeRadius, ceruleumBlue);
            bgDrawList.AddCircleFilled(new Vector2(innerPos.X, innerPos.Y + innerSize.Y), nodeRadius + Scaled(4f), ceruleumGlow);
            
            bgDrawList.AddCircleFilled(innerPos + innerSize, nodeRadius, ceruleumBlue);
            bgDrawList.AddCircleFilled(innerPos + innerSize, nodeRadius + Scaled(4f), ceruleumGlow);
            
            // Reinforcement Plates (Top and Bottom Centers)
            Vector2 topPlatePos = new Vector2(outerPos.X + outerSize.X / 2 - Scaled(120), outerPos.Y);
            Vector2 topPlateSize = Scaled(new Vector2(240, 24));
            bgDrawList.AddRectFilled(topPlatePos, topPlatePos + topPlateSize, darkIron, Scaled(4f));
            bgDrawList.AddRect(topPlatePos, topPlatePos + topPlateSize, edgeHighlight, Scaled(4f), 0, Scaled(1.5f));
            
            Vector2 bottomPlatePos = new Vector2(outerPos.X + outerSize.X / 2 - Scaled(80), outerPos.Y + outerSize.Y - Scaled(15));
            Vector2 bottomPlateSize = Scaled(new Vector2(160, 15));
            bgDrawList.AddRectFilled(bottomPlatePos, bottomPlatePos + bottomPlateSize, darkIron, Scaled(4f));
            bgDrawList.AddRect(bottomPlatePos, bottomPlatePos + bottomPlateSize, edgeHighlight, Scaled(4f), 0, Scaled(1.5f));
            
            // Side Hardware Button Panel (for close / minimize)
            float btnPanelY = outerPos.Y + Scaled(70);
            Vector2 btnPanelPos = new Vector2(outerPos.X + outerSize.X - Scaled(25), btnPanelY);
            Vector2 btnPanelSize = Scaled(new Vector2(25, 90));
            bgDrawList.AddRectFilled(btnPanelPos, btnPanelPos + btnPanelSize, darkIron, Scaled(4f));
            bgDrawList.AddRect(btnPanelPos, btnPanelPos + btnPanelSize, edgeHighlight, Scaled(4f), 0, Scaled(1.5f));
            
            // Individual button sockets (deep shadow)
            bgDrawList.AddRectFilled(btnPanelPos + Scaled(new Vector2(2, 5)), btnPanelPos + Scaled(new Vector2(23, 40)), UIHelper.Vec4ToU32(new Vector4(0.05f, 0.05f, 0.05f, 1.0f)), Scaled(2f));
            bgDrawList.AddRectFilled(btnPanelPos + Scaled(new Vector2(2, 45)), btnPanelPos + Scaled(new Vector2(23, 85)), UIHelper.Vec4ToU32(new Vector4(0.05f, 0.05f, 0.05f, 1.0f)), Scaled(2f));
            
            // Rivets on corners
            bgDrawList.AddCircleFilled(outerPos + Scaled(new Vector2(16, 16)), Scaled(3.5f), rivetColor);
            bgDrawList.AddCircleFilled(new Vector2(outerPos.X + outerSize.X - Scaled(16), outerPos.Y + Scaled(16)), Scaled(3.5f), rivetColor);
            bgDrawList.AddCircleFilled(new Vector2(outerPos.X + Scaled(16), outerPos.Y + outerSize.Y - Scaled(16)), Scaled(3.5f), rivetColor);
            bgDrawList.AddCircleFilled(outerPos + outerSize - Scaled(new Vector2(16, 16)), Scaled(3.5f), rivetColor);
        }

        public void Draw()
        {
            if (SettingsVisible)
            {
                if (this.configuration.IsMinimized)
                    DrawWidgetWindow();
                else
                    DrawSettingsWindow();
            }
        }
        
        private void DrawWidgetWindow()
        {
            ImGui.PushStyleColor(ImGuiCol.WindowBg, new Vector4(0, 0, 0, 0));
            ImGui.PushStyleColor(ImGuiCol.Border, new Vector4(0, 0, 0, 0));
            ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, new Vector2(0, 0));
            ImGui.PushStyleVar(ImGuiStyleVar.WindowBorderSize, 0.0f);

            ImGui.SetNextWindowSize(new Vector2(200, 100), ImGuiCond.Always);
            
            if (ImGui.Begin("NAGU-PAD Widget", ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.NoResize))
            {
                var winPos = ImGui.GetWindowPos();
                var winSize = ImGui.GetWindowSize();
                var drawList = ImGui.GetWindowDrawList();

                // Garlond Base Chassis
                uint gunmetal = UIHelper.Vec4ToU32(new Vector4(0.17f, 0.17f, 0.19f, 1.0f));
                uint darkIron = UIHelper.Vec4ToU32(new Vector4(0.12f, 0.12f, 0.14f, 1.0f));
                uint edgeHighlight = UIHelper.Vec4ToU32(new Vector4(0.3f, 0.3f, 0.35f, 1.0f));
                uint ceruleumBlue = UIHelper.Vec4ToU32(new Vector4(0.0f, 0.65f, 1.0f, 1.0f));
                uint ceruleumGlow = UIHelper.Vec4ToU32(new Vector4(0.0f, 0.65f, 1.0f, 0.3f));
                uint rivetColor = UIHelper.Vec4ToU32(new Vector4(0.08f, 0.08f, 0.09f, 1.0f));
                
                drawList.AddRectFilled(winPos, winPos + winSize, gunmetal, 8f);
                drawList.AddRect(winPos, winPos + winSize, edgeHighlight, 8f, 0, 1.5f);
                
                // Inner Screen
                Vector2 innerPos = winPos + new Vector2(4, 4);
                Vector2 innerSize = winSize - new Vector2(8, 8);
                drawList.AddRectFilled(innerPos, innerPos + innerSize, UIHelper.Vec4ToU32(new Vector4(0.04f, 0.05f, 0.08f, 0.95f)), 4f);
                drawList.AddRect(innerPos, innerPos + innerSize, ceruleumBlue, 4f, 0, 1.5f);

                // Small corner glowing nodes
                drawList.AddCircleFilled(innerPos, 2f, ceruleumBlue);
                drawList.AddCircleFilled(innerPos, 4f, ceruleumGlow);
                drawList.AddCircleFilled(new Vector2(innerPos.X + innerSize.X, innerPos.Y), 2f, ceruleumBlue);
                drawList.AddCircleFilled(new Vector2(innerPos.X + innerSize.X, innerPos.Y), 4f, ceruleumGlow);
                drawList.AddCircleFilled(new Vector2(innerPos.X, innerPos.Y + innerSize.Y), 2f, ceruleumBlue);
                drawList.AddCircleFilled(new Vector2(innerPos.X, innerPos.Y + innerSize.Y), 4f, ceruleumGlow);
                drawList.AddCircleFilled(innerPos + innerSize, 2f, ceruleumBlue);
                drawList.AddCircleFilled(innerPos + innerSize, 4f, ceruleumGlow);

                // Expand Button
                ImGui.SetCursorScreenPos(winPos + new Vector2(80, 30));
                ImGui.PushFont(Dalamud.Interface.UiBuilder.IconFont);
                ImGui.PushStyleColor(ImGuiCol.Text, new Vector4(0.0f, 0.65f, 1.0f, 1.0f));
                ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0,0,0,0));
                ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(0.0f, 0.65f, 1.0f, 0.2f));
                ImGui.PushStyleColor(ImGuiCol.ButtonActive, new Vector4(0.0f, 0.65f, 1.0f, 0.4f));
                ImGui.SetWindowFontScale(1.8f);
                if (ImGui.Button("\uf065", new Vector2(40, 40))) // FontAwesome expand icon
                {
                    this.configuration.IsMinimized = false;
                    this.configuration.Save();
                }
                ImGui.SetWindowFontScale(1.0f);
                ImGui.PopStyleColor(4);
                ImGui.PopFont();
                
                // Drag handle (invisible button covering the left side)
                ImGui.SetCursorScreenPos(winPos);
                ImGui.InvisibleButton("WidgetDrag", new Vector2(160, 100));
                
                // Close button (X)
                ImGui.SetCursorScreenPos(winPos + new Vector2(175, 8));
                ImGui.PushFont(Dalamud.Interface.UiBuilder.IconFont);
                ImGui.PushStyleColor(ImGuiCol.Text, new Vector4(0.6f, 0.65f, 0.7f, 1.0f));
                ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0,0,0,0));
                ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(1,1,1,0.1f));
                ImGui.PushStyleColor(ImGuiCol.ButtonActive, new Vector4(1,1,1,0.2f));
                if (ImGui.Button("\uf00d", new Vector2(18, 18))) // FontAwesome times/close
                {
                    SettingsVisible = false;
                }
                ImGui.PopStyleColor(4);
                ImGui.PopFont();
            }
            ImGui.End();

            ImGui.PopStyleVar(2);
            ImGui.PopStyleColor(2);
        }

        public static float AppScale { get; private set; } = 1.0f;
        public static bool HideScrollbars { get; private set; } = false;

        public static float Scaled(float value) => value * AppScale;
        public static Vector2 Scaled(Vector2 value) => new Vector2(value.X * AppScale, value.Y * AppScale);

        public void DrawSettingsWindow()
        {
            if (!SettingsVisible) return;

            HideScrollbars = this.configuration.HideScrollbars;

            ImGui.PushStyleColor(ImGuiCol.WindowBg, new Vector4(0, 0, 0, 0)); 
            ImGui.PushStyleColor(ImGuiCol.Border, new Vector4(0, 0, 0, 0));
            ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, new Vector2(0, 0));
            ImGui.PushStyleVar(ImGuiStyleVar.WindowBorderSize, 0.0f);

            switch (this.configuration.TabletSize)
            {
                case 0: AppScale = 0.80f; break; // XS
                case 1: AppScale = 0.90f; break; // S
                case 2: AppScale = 1.0f;  break; // M
                case 3: AppScale = 1.10f; break; // L
                case 4: AppScale = 1.20f; break; // XL
                default: AppScale = 1.0f; break;
            }

            Vector2 windowSize = new Vector2(1010 * AppScale, 770 * AppScale);
            ImGui.SetNextWindowSize(windowSize, ImGuiCond.Always);
            
            if (ImGui.Begin("NAGU-PAD Premium Tablet", ref settingsVisible, ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.NoResize))
            {
                ImGui.SetWindowFontScale(AppScale);

                if (!_verificationChecked && !_isVerifying) {
                    _isVerifying = true;
                    var localPlayer = _objectTable[0] as Dalamud.Game.ClientState.Objects.SubKinds.IPlayerCharacter;
                    if (localPlayer != null) {
                        string name = localPlayer.Name.ToString();
                        string world = localPlayer.HomeWorld.Value.Name.ExtractText();
                        System.Threading.Tasks.Task.Run(async () => {
                            _isVerified = await sender.VerifyUserAsync(name, world);
                            _verificationChecked = true;
                            _isVerifying = false;
                        });
                    } else {
                        // Not logged in or loading, wait.
                        _isVerifying = false; 
                    }
                }

                var winPos = ImGui.GetWindowPos();
                var winSize = ImGui.GetWindowSize();
                var drawList = ImGui.GetWindowDrawList();

                Vector2 contentPos = winPos + Scaled(new Vector2(21, 21));
                Vector2 contentSize = winSize - Scaled(new Vector2(42, 42));

                // Procedural Garlond Ironworks Frame (now encompasses the entire window)
                // Draw this FIRST so it acts as the true background layer of the window
                DrawGarlondFrame(drawList, winPos, winSize);

                // 1. Base Layer (Deep Space) - Drawn strictly inside the content boundaries
                drawList.AddRectFilled(contentPos, contentPos + contentSize, UIHelper.Vec4ToU32(new Vector4(0.02f, 0.03f, 0.05f, 1.0f)), 4f);
                
                // Content Background (Frosted Glass with blue tint)
                drawList.AddRectFilled(contentPos, contentPos + contentSize, UIHelper.Vec4ToU32(new Vector4(0.04f, 0.05f, 0.08f, 0.95f)), 0f);

                // 2. Constellation Particles (Draw after frosted glass so it's fully visible!)
                if (!this.configuration.HideBackgroundAnimation)
                {
                    _constellation.Draw(contentPos, contentSize, this.configuration.HideScanline);
                }
                drawList.AddRect(contentPos, contentPos + contentSize, UIHelper.Vec4ToU32(new Vector4(0f, 0.6f, 1f, 0.1f)), 0f, 0, 1f);

                // Custom Title Bar Drag Handle
                ImGui.SetCursorPos(new Vector2(0, 0));
                ImGui.InvisibleButton("TitleBarDrag", new Vector2(winSize.X, Scaled(25f)));

                // Title Text integrated into the top reinforcement plate, centered
                string displayTitle = "NAGU-PAD";
                if (sender.CurrentUserRole == "admin") displayTitle = "NAGU-PAD (Admin)";
                else if (sender.CurrentUserRole == "friend") displayTitle = "NAGU-PAD (Friends)";
                
                ImGui.SetWindowFontScale(0.85f * AppScale);
                var titleTextSize = ImGui.CalcTextSize(displayTitle);
                ImGui.SetCursorScreenPos(winPos + new Vector2(winSize.X / 2 - titleTextSize.X / 2, Scaled(12f) - titleTextSize.Y / 2));
                ImGui.TextColored(new Vector4(0.8f, 0.85f, 0.9f, 1.0f), displayTitle);
                ImGui.SetWindowFontScale(AppScale);
                
                // Hardware Buttons on the side panel
                Vector4 baseIconColor = new Vector4(0.6f, 0.65f, 0.7f, 1.0f);
                Vector4 closeHoverColor = new Vector4(1.0f, 0.2f, 0.2f, 1.0f);
                Vector4 minimizeHoverColor = new Vector4(0.0f, 0.65f, 1.0f, 1.0f);
                
                // Close Button (Top physical button)
                if (DrawHardwareButton(drawList, "CloseBtn", winPos + new Vector2(winSize.X - Scaled(23f), Scaled(75f)), Scaled(new Vector2(21, 35)), "\uf00d", baseIconColor, closeHoverColor))
                {
                    settingsVisible = false;
                }
                
                // Minimize Button (Bottom physical button)
                if (DrawHardwareButton(drawList, "MinimizeBtn", winPos + new Vector2(winSize.X - Scaled(23f), Scaled(115f)), Scaled(new Vector2(21, 40)), "\uf068", baseIconColor, minimizeHoverColor))
                {
                    this.configuration.IsMinimized = true;
                    this.configuration.Save();
                }

                // Sidebar
                float sidebarWidth = Scaled(80f);
                drawList.AddLine(contentPos + new Vector2(sidebarWidth, 0), contentPos + new Vector2(sidebarWidth, contentSize.Y), UIHelper.Vec4ToU32(new Vector4(1, 1, 1, 0.05f)));
                
                ImGui.SetCursorPos(Scaled(new Vector2(25, 30)));
                float availableHeight = contentSize.Y - Scaled(40f);
                ImGui.BeginChild("Sidebar", new Vector2(sidebarWidth, availableHeight), false, ImGuiWindowFlags.NoScrollbar);
                
                float slotHeight = availableHeight / 8f;
                float currentY = 0f;
                
                _flyoutQueue.Clear();

                float[] appHoverStates = new float[_apps.Count];
                int appIdx = 0;
                foreach (var app in _apps)
                {
                    ImGui.SetCursorPosY(currentY + (slotHeight / 2f) - Scaled(25f)); // Center the 50px icon vertically in the slot
                    appHoverStates[appIdx] = RenderSidebarIcon(app.Name, app.Icon, app == _selectedApp, () => _selectedApp = app);
                    currentY += slotHeight;
                    appIdx++;
                }

                // Subtle Divider
                Vector2 divStart = ImGui.GetCursorScreenPos() + new Vector2(0, (slotHeight / 2f) - Scaled(25f));
                Vector2 divEnd = divStart + new Vector2(sidebarWidth - Scaled(10f), 0);
                drawList.AddLine(divStart, divEnd, UIHelper.Vec4ToU32(new Vector4(1, 1, 1, 0.1f)));

                // Core Settings
                ImGui.SetCursorPosY(currentY + (slotHeight / 2f) - Scaled(25f));
                RenderSidebarIcon("Core Settings", ((char)Dalamud.Interface.FontAwesomeIcon.Cog).ToString(), _selectedApp == null, () => _selectedApp = null);

                ImGui.EndChild();


                // Main Content
                ImGuiWindowFlags mainFlags = ImGuiWindowFlags.None;
                if (this.configuration.HideScrollbars) mainFlags |= ImGuiWindowFlags.NoScrollbar;

                // Draw the unified background modal for the right pane stretching fully from top to bottom
                Vector2 rightPanePos = contentPos + new Vector2(sidebarWidth, 0);
                Vector2 rightPaneSize = new Vector2(contentSize.X - sidebarWidth, contentSize.Y);
                drawList.AddRectFilled(rightPanePos, rightPanePos + rightPaneSize, UIHelper.Vec4ToU32(new Vector4(1, 1, 1, 0.03f)), Scaled(4f), ImDrawFlags.RoundCornersRight);
                drawList.AddRect(rightPanePos, rightPanePos + rightPaneSize, UIHelper.Vec4ToU32(new Vector4(1, 1, 1, 0.05f)), Scaled(4f), ImDrawFlags.RoundCornersRight, 1.5f);

                // Restore padded margins for the actual content
                ImGui.SetCursorPos(new Vector2(Scaled(25f) + sidebarWidth + Scaled(20f), Scaled(25f))); 
                ImGui.BeginChild("MainContent", new Vector2(contentSize.X - sidebarWidth - Scaled(40f), contentSize.Y - Scaled(50f)), false, mainFlags);
                
                if (_selectedApp != null)
                {
                    ImGui.BeginGroup();
                    ImGui.SetWindowFontScale(1.1f);
                    _selectedApp.Draw();
                    ImGui.SetWindowFontScale(1.0f);
                    ImGui.EndGroup();
                }
                else
                {
                    DrawCoreSettings();
                }

                ImGui.EndChild();
                

                if (_verificationChecked && !_isVerified)
                {
                    drawList.AddRectFilled(contentPos, contentPos + contentSize, UIHelper.Vec4ToU32(new Vector4(0.05f, 0.05f, 0.05f, 0.92f)), Scaled(16f));
                    
                    float blink = (float)(Math.Sin(ImGui.GetTime() * 6.0) * 0.5 + 0.5);
                    Vector4 redColor = new Vector4(1.0f, 0.2f, 0.2f, 0.5f + blink * 0.5f);
                    
                    string alertTitle = "UNVERIFIED USER";
                    var titleSize = ImGui.CalcTextSize(alertTitle);
                    
                    ImGui.SetCursorScreenPos(contentPos + new Vector2(contentSize.X / 2 - (titleSize.X * 2.5f) / 2, contentSize.Y / 2 - Scaled(40f)));
                    ImGui.SetWindowFontScale(2.5f);
                    ImGui.TextColored(redColor, alertTitle);
                    ImGui.SetWindowFontScale(1.0f);
                    
                    string alertMsg = "Please register this character on the XIV Hub website to unlock plugin features.";
                    var msgSize = ImGui.CalcTextSize(alertMsg);
                    ImGui.SetCursorScreenPos(contentPos + new Vector2(contentSize.X / 2 - msgSize.X / 2, contentSize.Y / 2 + Scaled(10f)));
                    ImGui.TextColored(new Vector4(0.7f, 0.7f, 0.7f, 1.0f), alertMsg);
                }

                // Central Hazard Indicators (Segmented Status Bar embedded in the bottom frame plate)
                float totalWidth = Scaled(140f);
                float padding = Scaled(10f); // distance from edge of the 160px bottom plate
                float ledSpacing = Scaled(3f);
                float ledWidth = (totalWidth - (6 * ledSpacing)) / 7f;
                float ledHeight = Scaled(5f);
                
                float hazardStartX = winPos.X + (winSize.X / 2) - Scaled(80f) + padding;
                float hazardY = winPos.Y + winSize.Y - Scaled(15f) + Scaled(5f); // Center vertically in the 15px plate
                
                for (int i = 0; i < 7; i++)
                {
                    Vector4 indicatorColor = new Vector4(0.08f, 0.08f, 0.1f, 1.0f); // Default dim glass
                    float glowIntensity = 0f;

                    if (i < _apps.Count)
                    {
                        var app = _apps[i];
                        bool isSelected = (_selectedApp == app);
                        float hoverState = appHoverStates[i];
                        
                        // Active apps pulse brightly, hovered apps light up
                        if (isSelected)
                        {
                            float pulse = (float)(Math.Sin(ImGui.GetTime() * 5.0) * 0.15f + 0.85f);
                            indicatorColor = new Vector4(1.0f, 0.9f, 0.2f, pulse);
                            glowIntensity = pulse;
                        }
                        else if (hoverState > 0)
                        {
                            indicatorColor = UIHelper.LerpColor(new Vector4(0.08f, 0.08f, 0.1f, 1.0f), new Vector4(1.0f, 0.8f, 0.1f, 1.0f), hoverState);
                            glowIntensity = hoverState * 0.5f;
                        }
                    }
                    
                    float curX = hazardStartX + (i * (ledWidth + ledSpacing));
                    float curY = hazardY;
                    
                    Vector2 pMin = new Vector2(curX, curY);
                    Vector2 pMax = new Vector2(curX + ledWidth, curY + ledHeight);

                    if (glowIntensity > 0)
                    {
                        // Add external glow if illuminated (DRAW BEFORE CORE)
                        Vector4 glowColor = new Vector4(1.0f, 0.6f, 0.0f, glowIntensity * 0.5f); // Golden/Orange glow
                        drawList.AddRectFilled(pMin - Scaled(new Vector2(3f, 3f)), pMax + Scaled(new Vector2(3f, 3f)), UIHelper.Vec4ToU32(glowColor), Scaled(2f));
                    }
                    
                    // Draw the physical glass/lit element
                    drawList.AddRectFilled(pMin, pMax, UIHelper.Vec4ToU32(indicatorColor), Scaled(1f));
                    
                    if (glowIntensity > 0)
                    {
                        // Core highlight (DRAW ON TOP)
                        Vector2 hMin = pMin + Scaled(new Vector2(2f, 1f));
                        Vector2 hMax = pMax - Scaled(new Vector2(2f, 1f));
                        drawList.AddRectFilled(hMin, hMax, UIHelper.Vec4ToU32(new Vector4(1f, 1f, 1f, glowIntensity * 0.7f)), Scaled(0.5f)); // bright white core
                    }
                }

                // Draw Flyouts on top of the main window's draw list after all child windows
                // This guarantees they are drawn on top of the MainContent tab pane (fixing the overflow bug)
                foreach (var drawFlyout in _flyoutQueue)
                {
                    drawFlyout();
                }
            }
            ImGui.End();

            ImGui.PopStyleVar(2);
            ImGui.PopStyleColor(2);
        }

        private bool DrawHardwareButton(ImDrawListPtr drawList, string id, Vector2 pos, Vector2 size, string icon, Vector4 baseColor, Vector4 hoverColor)
        {
            ImGui.SetCursorScreenPos(pos);
            ImGui.InvisibleButton(id, size);
            bool isHovered = ImGui.IsItemHovered();
            bool isActive = ImGui.IsItemActive();
            bool isClicked = ImGui.IsItemClicked();

            uint baseId = ImGui.GetID(id);
            float hoverState = UIHelper.GetHoverState(baseId, isHovered, 10.0f);
            float activeState = UIHelper.GetHoverState(baseId ^ 0x12345678, isActive, 20.0f);

            // Animate Physical Press (shift slightly right when pressed)
            float pressOffset = activeState * 1.5f;
            Vector2 btnStart = pos + new Vector2(pressOffset, 0);
            Vector2 btnEnd = pos + size + new Vector2(pressOffset, 0);

            // Background Lerp
            Vector4 gunmetal = new Vector4(0.17f, 0.17f, 0.19f, 1.0f);
            Vector4 currentBg = UIHelper.LerpColor(gunmetal, hoverColor, hoverState * 0.25f);
            
            drawList.AddRectFilled(btnStart, btnEnd, UIHelper.Vec4ToU32(currentBg), 2f);
            
            // Highlight Edge (Top left edge catch light to make it look physical)
            drawList.AddLine(btnStart + new Vector2(1, 1), new Vector2(btnEnd.X - 1, btnStart.Y + 1), UIHelper.Vec4ToU32(new Vector4(1, 1, 1, 0.15f + hoverState * 0.2f)), 1f);
            drawList.AddLine(btnStart + new Vector2(1, 1), new Vector2(btnStart.X + 1, btnEnd.Y - 1), UIHelper.Vec4ToU32(new Vector4(1, 1, 1, 0.1f + hoverState * 0.1f)), 1f);

            // Text / Icon
            Vector4 currentText = UIHelper.LerpColor(baseColor, hoverColor, hoverState);
            
            ImGui.PushFont(Dalamud.Interface.UiBuilder.IconFont);
            var textSize = ImGui.CalcTextSize(icon);
            ImGui.SetCursorScreenPos(btnStart + new Vector2(size.X / 2 - textSize.X / 2, size.Y / 2 - textSize.Y / 2));
            ImGui.TextColored(currentText, icon);
            ImGui.PopFont();

            return isClicked;
        }

        private float RenderSidebarIcon(string name, string icon, bool isSelected, Action onClick)
        {
            ImGui.SetCursorPosX(Scaled(15f));
            var cursorPos = ImGui.GetCursorScreenPos();
            var size = new Vector2(Scaled(50f), Scaled(50f));
            
            ImGui.InvisibleButton(name, size);
            bool isHovered = ImGui.IsItemHovered();
            if (ImGui.IsItemClicked()) onClick();

            uint id = ImGui.GetID(name);
            float hoverState = UIHelper.GetHoverState(id, isHovered, 12.0f);
            var drawList = ImGui.GetWindowDrawList();

            // Background Lerp
            Vector4 baseBg = isSelected ? new Vector4(0.13f, 0.77f, 0.36f, 0.15f) : new Vector4(1, 1, 1, 0.0f);
            Vector4 hoverBg = isSelected ? new Vector4(0.13f, 0.77f, 0.36f, 0.25f) : new Vector4(1, 1, 1, 0.05f);
            Vector4 currentBg = UIHelper.LerpColor(baseBg, hoverBg, hoverState);
            
            drawList.AddRectFilled(cursorPos, cursorPos + size, UIHelper.Vec4ToU32(currentBg), Scaled(12f));

            if (isSelected)
            {
                drawList.AddRectFilled(cursorPos + new Vector2(-Scaled(10f), Scaled(10f)), cursorPos + new Vector2(-Scaled(7f), size.Y - Scaled(10f)), UIHelper.Vec4ToU32(new Vector4(0.13f, 0.77f, 0.36f, 1.0f)), Scaled(2f));
            }

            Vector4 baseText = isSelected ? new Vector4(0.13f, 0.77f, 0.36f, 1.0f) : new Vector4(0.6f, 0.65f, 0.7f, 1.0f);
            Vector4 hoverText = isSelected ? new Vector4(0.2f, 0.85f, 0.4f, 1.0f) : new Vector4(0.9f, 0.9f, 0.9f, 1.0f);
            Vector4 currentText = UIHelper.LerpColor(baseText, hoverText, hoverState);

            // Icon Scale Animation
            float baseScale = isSelected ? 1.4f : 1.2f;
            float targetScale = 1.6f;
            float currentScale = baseScale + (targetScale - baseScale) * hoverState;

            // Pulse if selected
            if (isSelected)
            {
                float pulse = (float)(Math.Sin(ImGui.GetTime() * 4.0) * 0.15f + 0.85f);
                currentText.W = pulse;
            }

            bool drawnImage = false;

            if (_textureProvider != null && pluginInterface != null)
            {
                if (!_sidebarIconCache.TryGetValue(name, out var sharedTex))
                {
                    try
                    {
                        string configDir = pluginInterface.ConfigDirectory.FullName;
                        if (!System.IO.Directory.Exists(configDir))
                            System.IO.Directory.CreateDirectory(configDir);
                            
                        string imgPath = System.IO.Path.Combine(configDir, name.Replace(" ", "") + ".png");
                        
                        if (!System.IO.File.Exists(imgPath))
                        {
                            try 
                            {
                                var field = typeof(IconData).GetField(name.Replace(" ", ""));
                                if (field != null)
                                {
                                    string base64 = (string)field.GetValue(null)!;
                                    System.IO.File.WriteAllBytes(imgPath, Convert.FromBase64String(base64));
                                }
                            } catch (Exception) { }
                        }

                        if (System.IO.File.Exists(imgPath))
                        {
                            sharedTex = _textureProvider.GetFromFile(new System.IO.FileInfo(imgPath));
                            _sidebarIconCache[name] = sharedTex;
                            _log.Info($"Loaded icon for {name} from {imgPath}");
                        }
                        else
                        {
                            _log.Warning($"Icon for {name} not found at {imgPath}");
                            _sidebarIconCache[name] = null;
                        }
                    }
                    catch (Exception)
                    {
                        _sidebarIconCache[name] = null;
                        sharedTex = null;
                    }
                }
                
                if (sharedTex != null)
                {
                    dynamic texWrap = sharedTex.GetWrapOrDefault();
                    if (texWrap != null)
                    {
                        float imgScale = (size.X * 0.7f) / (float)texWrap.Width;
                        imgScale *= currentScale / baseScale;

                        Vector2 imageSize = new Vector2((float)texWrap.Width * imgScale, (float)texWrap.Height * imgScale);
                        Vector2 iconPos = cursorPos + new Vector2(size.X / 2 - imageSize.X / 2, size.Y / 2 - imageSize.Y / 2);
                        
                        try 
                        {
                            drawList.AddImage(texWrap.ImGuiHandle, iconPos, iconPos + imageSize, Vector2.Zero, Vector2.One, UIHelper.Vec4ToU32(currentText));
                            drawnImage = true;
                        } 
                        catch (Exception) { }
                    }
                }
            }

            if (!drawnImage)
            {
                ImGui.PushFont(Dalamud.Interface.UiBuilder.IconFont);
                ImGui.SetWindowFontScale(currentScale);
                
                var iconSize = ImGui.CalcTextSize(icon);
                Vector2 iconPos = cursorPos + new Vector2(size.X / 2 - iconSize.X / 2, size.Y / 2 - iconSize.Y / 2);
                
                drawList.AddText(iconPos, UIHelper.Vec4ToU32(currentText), icon);
                
                ImGui.SetWindowFontScale(1.0f);
                ImGui.PopFont();
            }

            // Queue Flyout if hovering
            if (hoverState > 0.01f)
            {
                float localHover = hoverState; // capture
                Vector2 localPos = cursorPos;
                string localName = name;
                
                _flyoutQueue.Add(() => {
                    var fgDraw = ImGui.GetForegroundDrawList(); 
                    ImGui.SetWindowFontScale(1.15f);
                    var textSize = ImGui.CalcTextSize(localName);
                    ImGui.SetWindowFontScale(1.0f);

                    float flyoutWidth = textSize.X + Scaled(30f);
                    float flyoutHeight = Scaled(34f);
                    
                    float slideOffset = Scaled(10f) * (1.0f - localHover);
                    Vector2 flyPos = localPos + new Vector2(size.X + Scaled(15f) - slideOffset, size.Y / 2 - flyoutHeight / 2);
                    
                    Vector4 flyBg = new Vector4(0.08f, 0.08f, 0.1f, 0.95f * localHover);
                    Vector4 flyBorder = new Vector4(0.3f, 0.3f, 0.35f, 0.5f * localHover);
                    Vector4 flyText = new Vector4(0.9f, 0.9f, 0.95f, 1.0f * localHover);

                    fgDraw.AddRectFilled(flyPos, flyPos + new Vector2(flyoutWidth, flyoutHeight), UIHelper.Vec4ToU32(flyBg), Scaled(6f));
                    fgDraw.AddRect(flyPos, flyPos + new Vector2(flyoutWidth, flyoutHeight), UIHelper.Vec4ToU32(flyBorder), Scaled(6f), 0, 1.5f);
                    
                    ImGui.SetWindowFontScale(1.15f);
                    fgDraw.AddText(flyPos + new Vector2(Scaled(15f), flyoutHeight / 2 - textSize.Y / 2), UIHelper.Vec4ToU32(flyText), localName);
                    ImGui.SetWindowFontScale(1.0f);
                });
            }
            
            return hoverState;
        }

        private void DrawCoreSettings()
        {
            ImGui.BeginGroup();
            
            ImGui.SetWindowFontScale(1.1f);
            ImGui.TextColored(new Vector4(0.13f, 0.77f, 0.36f, 1.0f), "Synchronization Engine");
            ImGui.Dummy(new Vector2(0, 5));
            
            var enabled = this.configuration.IsSyncEnabled;
            if (UIHelper.DrawGarlondSwitchWithText("chk_sync", "Enable Live Background Sync", ref enabled))
            {
                this.configuration.IsSyncEnabled = enabled;
                this.configuration.Save();
            }
            
            ImGui.Dummy(new Vector2(0, 5));
            ImGui.TextWrapped("When enabled, this plugin acts as a silent companion, automatically pushing your character data, inventory, and active gear to your XIV Hub web dashboard in real-time.");
            
            ImGui.Dummy(new Vector2(0, 20));
            ImGui.TextColored(new Vector4(0.13f, 0.77f, 0.36f, 1.0f), "Tablet Size");
            ImGui.Dummy(new Vector2(0, 5));
            
            int currentSize = this.configuration.TabletSize;
            string[] sizes = new string[] { "Extra Small (640x480)", "Small (800x600)", "Medium (960x720)", "Large (1120x840)", "Extra Large (1280x960)" };
            if (ImGui.Combo("Size Option", ref currentSize, sizes, sizes.Length))
            {
                this.configuration.TabletSize = currentSize;
                this.configuration.Save();
            }
            
            ImGui.Dummy(new Vector2(0, 15));
            ImGui.TextColored(new Vector4(0.13f, 0.77f, 0.36f, 1.0f), "Appearance");
            ImGui.Dummy(new Vector2(0, 5));
            
            bool hideAnim = this.configuration.HideBackgroundAnimation;
            if (UIHelper.DrawGarlondSwitchWithText("chk_bg", "Hide Background Animation", ref hideAnim))
            {
                this.configuration.HideBackgroundAnimation = hideAnim;
                this.configuration.Save();
            }
            
            bool hideScan = this.configuration.HideScanline;
            if (UIHelper.DrawGarlondSwitchWithText("chk_scan", "Hide Scanline", ref hideScan))
            {
                this.configuration.HideScanline = hideScan;
                this.configuration.Save();
            }

            bool hideScroll = this.configuration.HideScrollbars;
            if (UIHelper.DrawGarlondSwitchWithText("chk_scroll", "Hide Scrollbars (Dynamic Fade)", ref hideScroll))
            {
                this.configuration.HideScrollbars = hideScroll;
                this.configuration.Save();
            }
            
            ImGui.Dummy(new Vector2(0, 15));
            ImGui.TextColored(new Vector4(0.13f, 0.77f, 0.36f, 1.0f), "XIV Hub Identity");
            ImGui.Dummy(new Vector2(0, 5));
            
            if (this.configuration.IsVerified)
            {
                string roleDisplay = "";
                if (sender.CurrentUserRole == "admin") roleDisplay = " [Admin]";
                else if (sender.CurrentUserRole == "friend") roleDisplay = " [Friend]";
                
                ImGui.TextColored(new Vector4(0.2f, 0.9f, 0.3f, 1.0f), $"✓ Verified{roleDisplay} (Token: {this.configuration.XivHubId})");
            }
            else
            {
                ImGui.TextColored(new Vector4(1, 0.4f, 0.4f, 1.0f), "✗ Unverified");
            }
            
            ImGui.Dummy(new Vector2(0, 5));
            Vector4 btnBg = new Vector4(0.12f, 0.12f, 0.14f, 1.0f);
            Vector4 btnHover = new Vector4(0.0f, 0.65f, 1.0f, 1.0f);
            Vector4 btnText = new Vector4(0.9f, 0.9f, 0.9f, 1.0f);
            Vector4 btnHoverText = new Vector4(1.0f, 1.0f, 1.0f, 1.0f);
            
            if (UIHelper.DrawGarlondButton("btn_verify", ImGui.GetCursorScreenPos(), new Vector2(150, 30), "Verify User ID", btnBg, btnHover, btnText, btnHoverText))
            {
                var player = _objectTable[0] as Dalamud.Game.ClientState.Objects.SubKinds.IPlayerCharacter;
                if (player != null)
                {
                    string name = player.Name.ToString();
                    string world = player.HomeWorld.Value.Name.ToString();
                    Task.Run(() => sender.VerifyUserAsync(name, world, this.configuration));
                }
            }
            ImGui.Dummy(new Vector2(0, 30));
            
            ImGui.Dummy(new Vector2(0, 20));
            ImGui.TextColored(new Vector4(0.13f, 0.77f, 0.36f, 1.0f), "Engine Telemetry");
            ImGui.Dummy(new Vector2(0, 5));
            
            ImGui.Text($"Total Sync Attempts: {sender.TotalSyncs}");
            ImGui.TextColored(sender.FailedSyncs > 0 ? new Vector4(1,0.3f,0.3f,1) : new Vector4(0.6f,0.65f,0.7f,1), $"Failed Syncs: {sender.FailedSyncs}");
            ImGui.Text($"Last Sync Time: {(sender.LastSyncTime == DateTime.MinValue ? "Never" : sender.LastSyncTime.ToString("HH:mm:ss"))}");
            ImGui.TextWrapped($"Connection Status: {sender.LastSyncStatus}");
            
            ImGui.Dummy(new Vector2(0, 20));
            ImGui.TextColored(new Vector4(1.0f, 0.4f, 0.4f, 1.0f), "Data Reset");
            ImGui.Dummy(new Vector2(0, 5));
            ImGui.TextWrapped("Warning: Wiping the calendar will delete all custom events across all devices for this character. Proceed with caution.");
            
            Vector4 redBtnBg = new Vector4(0.3f, 0.1f, 0.1f, 1.0f);
            Vector4 redBtnHover = new Vector4(0.8f, 0.2f, 0.2f, 1.0f);
            if (UIHelper.DrawGarlondButton("btn_wipe", ImGui.GetCursorScreenPos(), new Vector2(150, 30), "Wipe Calendar", redBtnBg, redBtnHover, btnText, btnHoverText))
            {
                ImGui.OpenPopup("Confirm Wipe Calendar");
            }
            ImGui.Dummy(new Vector2(0, 30));
            
            bool wipeModalOpen = true;
            if (ImGui.BeginPopupModal("Confirm Wipe Calendar", ref wipeModalOpen, ImGuiWindowFlags.AlwaysAutoResize))
            {
                ImGui.TextColored(new Vector4(1f, 0.2f, 0.2f, 1f), "Are you absolutely sure?");
                ImGui.Spacing();
                ImGui.TextWrapped("This will permanently delete all events for this character on the XIV Hub backend.");
                ImGui.Spacing(); ImGui.Spacing();
                
                if (UIHelper.DrawGarlondButton("btn_confirm_wipe", ImGui.GetCursorScreenPos(), new Vector2(120, 30), "Yes, wipe it!", redBtnBg, redBtnHover, btnText, btnHoverText))
                {
                    var player = _objectTable[0] as Dalamud.Game.ClientState.Objects.SubKinds.IPlayerCharacter;
                    if (player != null)
                    {
                        string name = player.Name.ToString();
                        string world = player.HomeWorld.Value.Name.ToString();
                        
                        Task.Run(async () => {
                            await sender.WipeCalendarAsync(name, world);
                        });
                    }
                    ImGui.CloseCurrentPopup();
                }
                ImGui.SameLine(0, 10);
                
                if (UIHelper.DrawGarlondButton("btn_cancel_wipe", ImGui.GetCursorScreenPos(), new Vector2(120, 30), "Cancel", btnBg, btnHover, btnText, btnHoverText))
                {
                    ImGui.CloseCurrentPopup();
                }
                ImGui.Dummy(new Vector2(0, 30));
                ImGui.EndPopup();
            }
            
            ImGui.SetWindowFontScale(1.0f);
            ImGui.EndGroup();
        }
    }
}
