using Dalamud.Bindings.ImGui;

namespace XIVHubCompanion.Apps
{
    public class GatheringApp : IApp
    {
        public string Name => "Gathering";
        public string Icon => ((char)Dalamud.Interface.FontAwesomeIcon.Leaf).ToString();

        private readonly DataSender _sender;

        public GatheringApp(DataSender sender)
        {
            _sender = sender;
        }

        public void Draw()
        {
            ImGui.Text("Gathering Route Auto-Completion");
            ImGui.Separator();
            
            ImGui.TextWrapped("Listens for inventory diffs and communicates with XIV Hub to tick off gathering route steps automatically.");
            
            // Diff logic will hook into inventory changes here
        }

        public void Dispose()
        {
        }
    }
}
